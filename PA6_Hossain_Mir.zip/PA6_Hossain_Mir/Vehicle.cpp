//Mir Hossain
//Vehicle Implementation File

#include "Vehicle.h"

Vehicle::Vehicle ()
{
	cout << "Vehicle: Default ctor" << endl;
}

Vehicle::Vehicle(const float * srcLLA)
{
  	SetLLA(srcLLA);
  	cout << "Vehicle: Parameterized ctor" << endl;
}

Vehicle::Vehicle(const Vehicle& srcV)
{
  	SetLLA(srcV.m_lla);
  	cout << "Vehicle: Copy ctor" << endl;
}

Vehicle::~Vehicle ()
{
  cout << "Vehicle: Desturction" << endl;
}

void Vehicle::SetLLA (const float* srcLLA)
{
  		if(!srcLLA)
    	return;
  
	int i = 0;
  		while (i < 3)
  		{
    			m_lla[i] = srcLLA[i];
    			++i;
  		}
}

const float * Vehicle::GetLLA() const
{
  	return m_lla;
}

Vehicle& Vehicle::operator=(const Vehicle& srcV)
{
  	cout << "Vehicle: Assignment" << endl;
  		
		if(this != &srcV)
  		{
    			SetLLA(srcV.m_lla);
  		}
    	return *this;
}

void Vehicle::Serialize (ostream& os)
{
	int i = 0;
  	os << "Vehicle @: [";
  		
		while (i < 2)
  		{
    			os << m_lla[i++] << ", ";
  		}
  		++i;
  		os << m_lla[i] << "]";
}

ostream& operator<<(ostream& os, Vehicle& srcV)
{
  	srcV.Serialize(os);
  	return os;
}
