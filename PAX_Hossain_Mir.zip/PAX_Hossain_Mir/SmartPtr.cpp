//Mir Hossain
//SmartPtr Implementation File
#include "SmartPtr.h"

using namespace std;

//Default Constructor
SmartPtr::SmartPtr( )
{
  	m_ptr = new DataType; //Keeps track if DT object through m_ptr
  	m_refcount = new size_t (1); //point value to 1 for refcount
  	cout << "SmartPtr Dflt-ctor allocation, RefCount =" << *m_refcount << endl; //spec cout
}

//Parameterized Constructor
SmartPtr::SmartPtr( DataType * data )
{
	cout << "SmartPtr Prmtrz-ctor from data pointer, RefCount =" << *m_refcount << endl;
  	m_ptr = data; //m_ptr keeps track of data
  	m_refcount = new size_t(0); //dynamically allocate size t and keep track with refcount
  
	if(m_ptr == NULL)
 	{
    		*m_refcount = 1; //SmartPtr does not correspond to valid memory
  	}
  	
	else
  	{
    		*m_refcount = 0;
    		cout << "Null pointer passed and no data is allocated" << endl;
  	}
  
  	cout << "SmartPtr Prmtrz-ctor from data pointer, RefCount =" << *m_refcount << endl;
 
}

//Copy Constructor
SmartPtr::SmartPtr( const SmartPtr& other ) 
{

	if(other.m_ptr == NULL) //Check NULL
  	{
		m_refcount = 0;
    		m_ptr = other.m_ptr; //Keep track of m_ptr using copy
    		m_refcount = other.m_refcount; //Build RefCount
    		(*m_refcount)++;
		cout << "SmartPtr Copy-ctor, RefCount =" << *m_refcount << endl;
  	}
  
	else 
  	{
    		//cout << "RefCount not incremented" << endl;
    		m_refcount = new size_t (0);
  	}
  
	cout << "SmartPtr Copy-ctor, RefCount =" << *m_refcount << endl; //(c)
}


//Destructor Note* Was supposed to use pointers for refcount, but caused seg fault
SmartPtr::~SmartPtr()
{
  	if(m_refcount > 0){
		//cout << "SmartPtr D-tor, RefCount =" << m_refcount << endl; //prints out memory address :(
    		(m_refcount)--;//When RefCount hits 0, then deallocate
		//delete m_refcount; //(c)
      		//delete m_ptr; //(c) <- Does this cause a memory leak?
  	
	}
	
	else
  	{
      		cout << "SmartPtr D-tor, RefCount =" << *m_refcount << endl; //(d)
      		delete m_refcount; //(c)
      		delete m_ptr; //(c)
  	}
}
    

SmartPtr& SmartPtr::operator=( const SmartPtr& rhs )
{
	if(this == &rhs) //First check if copy is the same 
    		return *this;

  
  	if(*m_refcount > 0){
    		(*m_refcount)--; //(a) Deallo if object is last
		//*m_refcount = 0;
		//cout << *m_refcount << endl;
	}
  	else if(*m_refcount = 0)
    	{
      		cout << *m_refcount << endl;
      		delete m_refcount;
      		delete m_ptr;
    	}

 }

//Dereference Dynaminc Memory Object
DataType& SmartPtr::operator*()
{
	//return *m_ptr; //I think this is right maybe? 
	//Both DataType functions cause a seg fault
}

DataType* SmartPtr::operator->(){

	//return m_ptr;

    }
