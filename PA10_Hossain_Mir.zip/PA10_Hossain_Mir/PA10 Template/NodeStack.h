/*
Mir Hossain
NodeStack Header+Implementation File
*/
#ifndef NodeStack_H_
#define NodeStack_H_

#include "DataType.h"

template <class T>
class Node;

template <class T>
std::ostream& operator<<(std::ostream& os, const Node<T>& srcNode);

template <class T>
class NodeStack;

template <class T>
std::ostream& operator<<(std::ostream& os, const NodeStack<T>& NodeStack);

//template class declaration
template <class T>
class Node{

	friend class NodeStack<T>;  //allows direct accessing of link and data from class NodeQueue

  	friend std::ostream& operator<< (std::ostream& os, const Node<T>& srcNode)
  	{
    		os << srcNode.m_data << std::endl;
    		return os;
  	}

public:
    	Node():
    	m_next( NULL )
	{
	}
	
	Node(const T& data, Node<T>* next = NULL) :
	m_next( next ),
	m_data( data )
	{
	}
	
	Node(const Node<T>& other) :
	m_next( other.m_next ),
	m_data( other.m_data )
	{
	}

    	T& getData()
    	{  
      	return m_data;
    	}

    T& setData(int intVal, double doubleVal)
    {
      	m_data.setIntVal(intVal);
      	m_data.setDoubleVal(doubleVal);
      	return m_data;
    }

    const T& getData() const
    {  
      	return m_data;
    }

    Node<T>* getNext() const 
    {
      	return m_next;
    }

private:
    	Node<T>* m_next;
    	T m_data;
};

template <class T>
class NodeStack{
  
  	friend std::ostream& operator<< < >(std::ostream& os, const NodeStack<T>& NodeStack);
public:
	NodeStack();
    	NodeStack(size_t count, const T& value);
    	NodeStack(const NodeStack<T>& other);
    	~NodeStack();

    	NodeStack<T>& operator= (const NodeStack<T>& rhs);

    	T& top();
    	const T& top() const;

    	void push(const T& value);
    	void pop();

    	size_t size() const;
    	bool empty() const;
    	bool full() const;
    	void clear();
    	void serialize(std::ostream& os) const;

private:
    	Node<T>* m_top;
};





////////////////////////////////////////////Implementation///////////////////////////////I hate templates////////////

/*
Default constructor:
New stack with no elements     
*/
template <class T>
NodeStack<T>::NodeStack() //1 Done
{
  m_top = NULL;
}

/*
Parameterized constructor:
Invokes a list of new nodes has the size as "count" and fills the list
using the ordered pair
*/
template <class T>
NodeStack<T>::NodeStack(size_t count, const T& value) //2 Done
{
	m_top = new Node<T>(value); //Dynamically allocate node
    	Node<T> * current = m_top;
    
    	while (--count > 0)
    	{
      		current = new Node<T>(value);
      		current->m_next = m_top;
      		m_top = current; //Fill the list with the ordered pair form DataType
  	}
   	
    	current = NULL; //Deallocate
    	delete current;  
}

/*
Copy constructor:
Makes copy of stack object from parameterized constructor
Same exact thing from NodeQueue, just deleted tail
*/
template <class T>
NodeStack<T>::NodeStack(const NodeStack<T>& other) //3 Done
{
	Node<T> * otherCurrent = other.m_top;
    	m_top = new Node<T>(otherCurrent->m_data);
    	Node<T> * current = m_top;
    	otherCurrent = otherCurrent->m_next; //Makes copy; set up otherCurrent

    	while (otherCurrent)
    	{
      		current->m_next = new Node<T>(otherCurrent->m_data); //DMA
      		current = current->m_next; //Keep making new values for current
      		otherCurrent = otherCurrent->m_next; //Copy set
    	}
    
    	current = NULL;
    	otherCurrent = NULL;
    	delete current;
    	delete otherCurrent;  
}

/*
Clear:
Clears the contents of a list and makes empty.
*/
template <class T>
void NodeStack<T>::clear() //12 Done
{
	 if(m_top)
  	 {
    		Node<T> * deleteQueue = m_top;
    			while(m_top) //Start from top
    			{
      				m_top = m_top->m_next; //Traverse
      				deleteQueue->m_next = NULL; //Makes values NULL
      				delete deleteQueue; //Delete
      				deleteQueue = m_top;
    			}
    		deleteQueue = NULL;
    		delete deleteQueue;
  	}
}

/*
~NodeStack:
Same as clear()
*/
template <class T>
NodeStack<T>::~NodeStack() //4 Done
{
	clear();  
}

/*
operator=
Compare right hand/left hand
*/
template <class T>
NodeStack<T>& NodeStack<T>::operator= (const NodeStack<T>& rhs)	//5 Done
{
	if(this == &rhs)
    	return *this; 
}

/*
empty():
Checks if NodeStack is empty
**Moved empty up since I'll be ref. it for
the next functions
*/
template <class T>
bool NodeStack<T>::empty() const				
{
	if(!m_top)
	{
		return true;
	}
	
	else
	
		return false;
}

/*
top():
Returns a reference to the top element stack.
*/
template <class T>
T& NodeStack<T>::top() //6a done
{
	empty(); //empty check
	
	return m_top->m_data;  
}


/*
Same as above
*/
template <class T>
const T& NodeStack<T>::top() const //6b done
{
	empty(); //empty check
	
	return m_top->m_data; 
}

/*
push():
Inputs a new value on top of stack
*/
template <class T>
void NodeStack<T>::push(const T& value) //7 done
{
	Node<T> *tempVal = new Node<T>(value); //make a new spot
	tempVal->m_next = m_top; //Makes a new top
	m_top = tempVal;  
	tempVal = NULL;
	delete tempVal;  
}

/*
pop():
Removes top value in stack
*/
template <class T>
void NodeStack<T>::pop() //8 done
{
	empty(); //empty check
	
	Node<T> * tempVal = m_top; //Make buffer to take spot of head 
	m_top = m_top->m_next; //Give new val to m_front
	tempVal = NULL; 
	delete tempVal; //get rid of old head  
}

/*
size():
Returns the size of stack list
*/
template <class T>
size_t NodeStack<T>::size() const  //9 done
{
	size_t queueSize = 0;
	if(m_top)
	{
		Node<T> * current = m_top;
		while(current)
		{
			++queueSize;
			current = current->m_next;
		}
	current = NULL;
	delete current;
	}
	
	return queueSize;  
}

/*
full():
Check if the stack is full or not
Full size is 7 
*/
template <class T>
bool NodeStack<T>::full() const
{
	 
}

/*
operator<<:
Outputs contents of a list 
*/
template <class T>
std::ostream& operator<<(std::ostream& os, const NodeStack<T>& srcstack)
{
 	srcstack.serialize(os);
    	return os;  
}

/*
serialize:
Display list   
*/
template <class T>
void NodeStack<T>::serialize(std::ostream& os) const
{
 	Node<T> * current = m_top;
    		
    	size_t i = 1;
    	while(current)
    	{
      		os << current->getData();
      		++i;
      		current = current->getNext();
    	} 
}

#endif //NodeStack_H_
