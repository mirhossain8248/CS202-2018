//Mir Hossain
//Header file for Vehicle 

#ifndef _VEHICLE_H
#define _VEHICLE_H

#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;

	class Vehicle
{
  	public:
    	Vehicle();
    	Vehicle(int srcVin, float* srcLLA); //parametrized constructor
    	Vehicle(const Vehicle& srcVehicle); //copy constructor
    	~Vehicle(); //destructor
    	Vehicle& operator= (const Vehicle& srcVehicle); //assignment operator
    	int getVin() const;
    	float* getLLA();
    	static int getIdgen();
    	void move(float* srcDest); //move car requirement - Also not done (yet)
    	bool setLongLat (float* srcDest);
	
	friend ostream& operator<<(ostream& os, const Vehicle& srcVehicle); //insertion operator - does not work (yet)
  
	protected:
    	float m_lla [3];
    	const int m_vin;

  	private:
      	static int s_idgen;
      	static int setVin (int srcVin);
};

#endif 