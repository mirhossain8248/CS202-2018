/*Mir Hossain
Proj10
Driver File for NodeStack, DataList, ArrayStack
*/

#include <iostream>

#include "ArrayStack.h"
#include "NodeStack.h"
//#include "DataType.cpp"
//#include "NodeStack.cpp" 
//#include "ArrayStack.cpp" 

using namespace std;

int main()
{
	
	cout << "-----------------" << endl;
	cout << "Testing DataType" << endl;
	cout << "-----------------" << endl;

  	DataType myData;
  	cout << "(A)Default Constructor: " << myData << endl;

  	DataType otherData(8, 6.9);
  	//cout << endl << "Pctor check" << endl;
  	cout << "(B)Parameterized Constructor: " << otherData << endl;

  	DataType copyData(otherData);
  	//cout << endl << "Copy ctor check" << endl;
  	cout << "(C)Copy Constructor: " << copyData << endl;

  	DataType assignData = otherData;
  	cout << "(D)Operator =: " << assignData << endl; 

  	//cout << endl << "Test DataType getIntVal()" << endl;
  	cout << "(E)getIntVal(): " << copyData.getIntVal() << endl;

  	//Test DataType setIntVal()
  	//cout << endl << "Test setIntVal()" << endl;
  	copyData.setIntVal(8);
  	cout << "(F)setIntVal: " << copyData.getIntVal() << endl;

  	//cout << endl << "Test DataType getDoubleVal()" << endl;
  	cout << "(G)getDoubleVal: " << copyData.getDoubleVal() << endl;

	//cout << endl << "Test DataType SetDoubleVal()" << endl;
  	copyData.setDoubleVal(6.9);
  	cout << "(H)setDoubleVal: " << copyData.getDoubleVal() << endl;

	cout << "----------------" << endl;
	cout << "DataType Class - Done" << endl;
	cout << "----------------" << endl;
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << endl << "-----------------" << endl;
	cout << "Testing Node Class" << endl;
	cout << "-----------------" << endl;

	Node myNode;
  	cout << "(I)Default Node: "<< myNode;

	Node otherNode(copyData);
  	cout << "(J)Other Node: " << otherNode;

	Node copyNode(otherNode);
  	cout << "(K)Copy Node: " << copyNode;
  	
 	cout << "----------------" << endl;
	cout << "Node Class - Done" << endl;
	cout << "----------------" << endl;
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << endl << "-----------------" << endl;
	cout << "Testing NodeStack Class" << endl;
	cout << "-----------------" << endl;
	
	//cout << endl << "Test NodeStack default C-tor" << endl;
	NodeStack newList;
	cout << "(1)Default Constructor:(Empty) " << newList << endl;
	
	//cout << endl << "Test NodeStack parameterized C-tor " << endl;
  	NodeStack otherList(3, copyData);
  	cout << "(2)Parameterized Constructor: " << otherList << endl;
  	
  	//cout << endl << "TestNodeStack Copy" << endl;
  	NodeStack copyList(otherList);
  	cout << "(3)Copy Constructor: " << copyList << endl;
  	
  	cout << "(4)Destructor" << endl;
  	
  	//cout << endl << "Test NodeStack Operator=" << endl;
  	NodeStack assignList(3, copyData);
  	assignList = otherList;
  	cout << "(5)Operator=: " << assignList << endl;
  	
  	DataType top = otherList.top();
  	cout << "(6a)Top: " << top << endl;
  	cout << "(6b)Top Const: " << top << endl;
  	
  	//cout << endl << "Test NodeStack push()" << endl;
  	DataType Newtop(12, 16.6);
  	otherList.push(Newtop);
  	cout << "(7)Push: " << otherList << endl;
  	
  	//cout << endl << "Test NodeStack pop()" << endl;
  	otherList.pop();
  	cout << "(8)Pop: " << otherList << endl;
  	
  	//cout << endl << "Test NodeStack size() " << endl;
  	cout << "(9)Size: " << otherList.size() << endl;
  	
  	if(otherList.empty()) 
  	{
  		cout << "(10)Empty: NodeStack list is empty" << endl;
  	}
  	else
  	{
  		cout << "(10)Empty: NodeStack list isn't empty" << endl;
  	}
  	
  	cout << "(11)Assume that maxSize is 7" << endl;
  	if(otherList.full())
  	{
  		cout << "(11)Full: NodeStack isn't full" << endl;
  	}
  	else
  	{
  		cout << "(11)Full: NodeStack is full" << endl;
  	}
  	
  	//cout << endl << "Test NodeStack clear()" << endl;
  	otherList.clear();
  	cout << "(12)Clear: " << otherList << endl;
  	
  	cout << "(13)Serialize" << endl;
  	
  	cout << endl << "-----------------" << endl;
	cout << "NodeStack - Done" << endl;
	cout << "-----------------" << endl;

/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << endl << "-----------------" << endl;
	cout << "Testing ArrayStack Class" << endl;
	cout << "-----------------" << endl;
	
	//cout << endl << "Test ArrayStack default" << endl;
  	ArrayStack defaultArray;
  	cout << "(1)Default Constructor:(Empty) " << defaultArray << endl;
  	
  	//cout << endl << Test ArrayStack Pctr" << endl;
  	ArrayStack otherArray(3, copyData);
  	cout << "(2)Parameterized Constructor: " << otherArray << endl;
  	
  	//cout << endl << "Test ArrayStack Copy" << endl;
  	ArrayStack copyArray(otherArray);
  	cout << "(3)Copy Constructor: " << copyArray << endl;
  	
  	cout << "(4)Destructor" << endl;
  	
  	//cout << endl << "Test ArrayStack Assignment" << endl;
	ArrayStack assignmentArray = otherArray;
	cout << "(5)Operator =: " << assignmentArray << endl;
	
	//cout << endl << Test ArrayStack top/constTop << endl;
	DataType arrayTop = otherArray.top();
	cout << "(6a)Top: " << arrayTop << endl;
	cout << "(6b)Const Top: " << arrayTop << endl;
	
	//cout << endl << "Test ArrayStack push << endl; 
  	DataType pushValue(36, 64.8);
  	otherArray.push(pushValue);
  	cout << "(7)Push: " << otherArray << endl;
  	
  	//cout << endl << "Test ArrayStack Pop << endl;
  	otherArray.pop();
  	cout << "(8)Pop: " << otherArray << endl;
  	
  	//cout << endl << "Test ArrayStack Size << endl;
  	 cout << "(9)Size: " << otherArray.size() << endl;
  	 
  	 //cout << endl << Test ArrayStack Empty << endl;
  	//Test if array is empty
  	//otherArray.clear(); //works
  	if(otherArray.empty()) 
  	{
  		cout << "(10)Empty: ArrayStack list is empty" << endl;
  	}
  	else
  	{
  		cout << "(10)Empty: ArrayStack list isn't empty" << endl;
  	}
  	
  	//cout << endl << "Test ArrayStack Full" << endl;
  	//Tested both ways
  	if(otherArray.full()) 
  	{
  		cout << "(11)Full: ArrayStack list is full" << endl;
  	}
  	else
  	{
  		cout << "(11)Full: ArrayStack list isn't full" << endl;
  	}
  	 
  	 
  	 
  	 //cout << endl << "Test ArrayQueue Clear" << endl'
  	otherArray.clear();
  	cout << "(12)Clear: " << otherArray << endl;
  	
  	cout << "(13)Serialize " << endl;
}
