/*Mir Hossain
Proj8
Driver File for NodeList, DataList, ArrayList
*/

#include <iostream>

#include "ArrayList.h"
#include "NodeList.h"
//#include "DataType.cpp"
//#include "NodeList.cpp" 
//#include "ArrayList.cpp" 

using namespace std;

int main(){
	
	cout << "-----------------" << endl;
	cout << "Testing DataType" << endl;
	cout << "-----------------" << endl;

  
  	DataType myData;
  	cout << "(A)Default C-tor: " << myData << endl;

  	
  	DataType otherData(5, 6.4);
  	//cout << endl << "Pctor check" << endl;
  	cout << "(B)Parameterized Constructor: " << otherData << endl;

  	
  	DataType copyData(otherData);
  	//cout << endl << "Copy ctor check" << endl;
  	cout << "(C)Copy Constructor: " << copyData << endl;

  	
  	if(copyData == otherData)
    		cout << "(D)Operator == [Same]" << endl;
  	else
    		cout << "(D)Operator == [Different]" << endl;

  	
  	//cout << endl << "Test DataType getIntVal()" << endl;
  	cout << "(E)getIntVal(): " << copyData.getIntVal() << endl;

  	//Test DataType setIntVal()
  	//cout << endl << "Test setIntVal()" << endl;
  	copyData.setIntVal(7);
  	cout << "(F)setIntVal: " << copyData.getIntVal() << endl;

  
  	//cout << endl << "Test DataType getDoubleVal()" << endl;
  	cout << "(G)getDoubleVal: " << copyData.getDoubleVal() << endl;

	
  	//cout << endl << "Test DataType SetDoubleVal()" << endl;
  	copyData.setDoubleVal(14.5);
  	cout << "(H)setDoubleVal: " << copyData.getDoubleVal() << endl;

	cout << "----------------" << endl;
	cout << "DataType Class - Done" << endl;
	cout << "----------------" << endl;
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	cout << endl << "-----------------" << endl;
	cout << "Testing Node Class" << endl;
	cout << "-----------------" << endl;

	Node myNode;
  	//cout << endl << "Default node ctor check" << endl;
  	cout << "(1)Default Node Constructor: " << myNode;

	//cout << endl << "Test Parameterized Node C-tor" << endl;
  	Node otherNode(copyData);
  	//cout << "Test Node Parameterized C-tor" << endl;
  	cout << "(2)Parameterized Node Constructor: " << otherNode; //Should be 7,14

	//cout << endl << "Test Copy C-tor" << endl;
  	Node copyNode(otherNode);
  	//cout << "Node Copy C-tor" << endl;
  	cout << "(3)Copy Node Constructor: " << copyNode;

	cout << "(4)Destructor\n";

	//cout << endl << "Test operator = " << endl;
	Node rhsNode(otherNode);
	cout << "(5)Operator=: " << rhsNode;

	cout << "----------------" << endl;
	cout << "Node Class - Done" << endl;
	cout << "----------------" << endl;
//////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	cout << endl << "-----------------" << endl;
	cout << "Testing NodeList Class" << endl;
	cout << "-----------------" << endl;

	DataType originalData(7, 14.5); //couldn't figure out how to pass data
	NodeList newList;
	//newList(originalData);

	//cout << "test: " << newList << endl;
	

	//cout << endl << "Test Head" << endl;
	NodeList NodeHead;
	NodeHead.head();
	cout << "(6)Address of Head: " << NodeHead.head() << endl;

	//cout << endl "Test Tail" << endl;
	NodeList NodeTail;
	//NodeHead.tail();
	cout << "(7)Address of Tail: " << NodeTail.tail() << endl;
	
	DataType toFind(7, 14.5);
	bool found;
  	Node * prev = NULL;
  	cout << "**Find doesn't really work";
  	cout << "(8)Find(): ";
  	//Node * found = otherNode.Find(toFind, prev);
  
	if(found)
  	{
    		cout << originalData <<  endl;
  	}
  
	else
   		cout << "No match found" << endl;

	
	//cout << endl << Test NodeList insertAfter << endl;
	DataType afterData(30, 15.0);
	newList.insertAfter(originalData,copyData); 
   	//cout << "Insertion Test" << endl;
	//cout << "(9)insertAfter: " << originalData << afterData  << endl;
	cout <<"(9)insertAfter: " << newList; 

	//cout << endl << "Testing Nodelist insertBefore" << endl;
   	DataType beforeData(60, 16.0);
	newList.insertBefore(beforeData, copyData); 
   	//cout << "(10)insertBefore: " << beforeData << originalData << afterData << endl;
	cout <<"(10)insertBefore: " << newList; 
	

	//cout << endl << "Test NodeList Erase" << endl;
   	//cout << "Erase successful" << endl;
	newList.erase(copyData);
   	cout << "(11)Erase: " << copyData << endl;
	
	cout << "(12a)/(12b) - (Causes Seg Fault)" << endl;

	//cout << "Test Operator[]
	//cout << "(12)Operator[]: " << newList[1] << endl; //Causes seg fault
	
	//cout << endl << "Test NodeList size" << endl;
	int len;
	//newList.size;
   	cout << "(13)Length: " << len << endl;

	//cout << endl << "Test NodeList empty()" << endl;
  	NodeList im;
   	if(newList.empty())
    		cout << "(14)Empty List" << endl;
   
	else
    		cout << "(14)Not Empty List" << endl;

	//cout << endl << "Test Clear()" << endl;
  	//NodeList tempList;
  	//cout << "worked" << endl;
 
 	 if(newList.size() > 0)
  	{
    		newList.clear();
    			//if(tempList.empty())
      cout << "(15)List empty" << endl; 
	}

	
	cout << "----------------" << endl;
	cout << "NodeList Class - Not Done" << endl;
	cout << "----------------" << endl;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	

	cout << endl << "-----------------" << endl;
	cout << "Testing ArrayList Class" << endl;
	cout << "-----------------" << endl;

	//cout << "Test ArrayList Default" << endl;
	cout << "(1)Default Constructor" << endl;
	//nothing to display

	//cout << endl << "Test ArrayList Parameterized c-tor" << endl;
  	ArrayList paramList(4, copyData);
  	//cout << "Parameterized constructor works" << endl;
  	cout << "(2)Parameterized Constructor: " << paramList << endl;

	//cout << endl << "Test ArrayList Copy c-tor" << endl;
  	ArrayList copyList(paramList);
  	cout << "(3)Copy Constructor: " << copyList << endl;

	//cout << "Test Destructor" << endl;
	cout << "(4)Destructor" << endl;
	//nothing to display

	//cout << endl << "Test ArrayList Assignment" << endl;
  	copyList = paramList;
  	//cout << "Assignment Works" << endl;
  	cout << "(5)Operator=: " << copyList << endl;

	//cout << endl << "Test ArrayList front()" << endl;
  	cout << "(6)Front: " << *paramList.front() << endl;

	//cout << endl << "Test ArrayList back()" << endl;
  	cout << "(7)Back: " << *paramList.back() << endl;

	//cout << endl << "Test ArrayList Find()" << endl;
  	DataType testVal(7, 14.5);
  	DataType * previous = NULL;
  	cout << "(8)Find: " << *paramList.find(testVal, previous) << endl;

	cout << "(9)insertAfter: -Not Done" << endl;
	cout << "(10)insertBefore -Not Done" << endl;
	
	cout << "(11)Erase - Implementation Done need to test(Gives Error)" << endl;
	//cout << paramList.erase << endl;

	//cout << endl << Test operator[] << endl;
	cout << "(12)Operator[3]:" << paramList[3] << endl;
	
	//cout << endl << "Test Size" << endl;
	cout << "(13)Size: Implementation Done need to test(Gives Error)" << endl;
	//cout << "(13)Size:" << paramList.size << endl; 

	

	

	
	cout << "----------------" << endl;
	cout << "ArrayList Class - Not Done" << endl;
	cout << "----------------" << endl;
	

	
	
	



	 

	
}
