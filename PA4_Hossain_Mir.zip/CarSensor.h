//Header for Car Sensors
#ifndef CarSensor_h
#define CarSensor_h

void strcpy(char *dest, const char *src);
int strcmp(char *name1, char *name2);
char* strcat(char* dest, const char* src);

class CarSensor
{
  	public:
    	CarSensor();
    	CarSensor(char* TypeA);
    	CarSensor(CarSensor& obj);

    	const char* getType() const;
    	float getExtraCost() const;
    	int getNumSensor() const;
    	int getGPS() const;
    	int getCamera() const;
    	int getLidar() const;
    	int getRadar() const;

    	void setType(char* newType);
    	void setExtraCost(char *sensorType);

    	void getReset() const;
    	bool operator == (CarSensor& obj);

  	private:
    	char m_type[50];
    	float m_extracost;
    	int m_num_sensors;
    	static int gps_cnt;
    	static int camera_cnt;
    	static int lidar_cnt;
    	static int radar_cnt;
};

#endif
