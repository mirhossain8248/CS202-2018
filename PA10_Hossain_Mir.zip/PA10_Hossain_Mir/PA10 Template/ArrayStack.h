/*Mir Hossain
ArrayStack Header+Implementation with Template
*/
#ifndef ArrayStack_H_
#define ArrayStack_H_

#include "DataType.h"

const size_t MAX_STACKSIZE = 1000;

template <class T>
class ArrayStack;

template <class T>
std::ostream& operator<<(std::ostream& os, const ArrayStack<T>& arrayStack);


template <class T>
class ArrayStack{


	friend std::ostream& operator<<(std::ostream& os, const ArrayStack<T>& arrayStack)
	{
		arrayStack.serialize(os);
      		return os;
	}
public:
    	ArrayStack();
    	ArrayStack(size_t count, const T& value); 
    	ArrayStack(const ArrayStack<T>& other); 
    	~ArrayStack();							    			

    	ArrayStack<T>& operator= (const ArrayStack<T>& rhs);			

    	T& top();
    	const T& top() const;

    	void push(const T& value);
    	void pop();

    	size_t size() const;									
    	bool empty() const;
    	bool full() const;									
    	void clear();
    	void serialize(std::ostream& os) const;						

private:
    	DataType m_container[MAX_STACKSIZE];
    	size_t m_top;
};




////////////////////////////////////////////Implementation////////////////////////////////////////////////////////////////////////

/*
Default Constructor:
New ArrayStack with nothing
*/
template <class T>
ArrayStack<T>::ArrayStack() //1 Done
{
	m_top = 0;
}

/*
Parameterized Constructor:
Takes in  count and DataType values, and creates the list
*/
template <class T>
ArrayStack<T>::ArrayStack(size_t count, const T& value)	//2 done
{
	size_t i = 0;
	m_top = count; //initilize values

	
	while(i < m_top)
	{
      		m_container[i] = value; //fill array
      		++i; //Seperated b/c made 0,0 first element in the stack
      	} 
}

/*
Copy Constructor:
Create a copy of array created in previous function   
*/
template <class T>
ArrayStack<T>::ArrayStack(const ArrayStack<T>& other) //3 done
{
	m_top = other.m_top; //copy top
	size_t i = 0;
	
	while(i < m_top)
	{
		m_container[i] = other.m_container[i];
		i++;
	}  
}

/*
destructor:
Not needed, but does same thing as clear
so I called clear and left
*/
template <class T>
ArrayStack<T>::~ArrayStack() //4 done							   
{
	clear();	 
}

/*
Operator=
Checks if rhs and lhs are the same
*/
template <class T>
ArrayStack<T>& ArrayStack<T>::operator= (const ArrayStack<T>& rhs) //5 done			
{
	if(this == &rhs)
		return *this;  
}

/*
top:
Returns head of stack
*/
template <class T>
T& ArrayStack<T>::top() //6a done
{
	if(!empty()) //Checks if array isn't empty
  		return m_container[m_top-1];  
}

/*
const top:
Returns head of stack
*/
template <class T>
const T& ArrayStack<T>::top() const //6b done
{
	if(!empty()) //Checks if array isn't empty
  		return m_container[m_top-1];  
}

/*
push:
Inserts a new value to the back of the queue, should check if queue is full
*/
template <class T>
void ArrayStack<T>::push(const T& value) //7 done
{
	if(full())
	{
		return;
	}
	
	else
	{
		m_container[m_top++] = value;
	}		  
}

/*
pop:
Removes top element of stack and checks empty
*/
template <class T>
void ArrayStack<T>::pop() //8 done
{
	if(empty())
  	{
  		return;
  	}
  	
  	else
  	{
  		(--m_top);
  	}  
}

/*
size():
Returns the size of stack
*/
template <class T>
size_t ArrayStack<T>::size() const //9 done
{
	return m_top;  
}

/*
empty():
Checks if stack is empty
*/
template <class T>
bool ArrayStack<T>::empty() const //10 done
{
	if(m_top == 0)
 	{
 		return true;
 	}
 	else
 	{
 		return false;
 	}   
}

/*
full:
Check if max stacksize is = to size of array //11 done
*/
template <class T>
bool ArrayStack<T>::full() const
{
	if(m_top == (MAX_STACKSIZE-1))
	{
		return true;
	}
	
	else
	{
		return false;
	}  
}

/*
clear():
Clears the contents of m_top  
*/
template <class T>
void ArrayStack<T>::clear()	 //12 done										
{
	while(m_top) 
	{
		(m_top--);
		m_container[m_top];
  
	}   
}

/*
serialize:
Displays the contents of the array based list using the ostream variable
passed in.
*/
template <class T>
void ArrayStack<T>::serialize(std::ostream& os) const
{
	if(m_top > 0)
  	{
    		size_t i = 0;
    			while (i < m_top)
    			{
      				os << m_container[i];
      				++i;
    			}
  	} 
}



#endif //ArrayStack_H_
