//Mir Hossain
//Vehicle Header

#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>

using namespace std;

	class Vehicle
	{	
		public:
		Vehicle();
  		Vehicle(const float* srcLLA);
  		Vehicle(const Vehicle& srcV);
		Vehicle& operator=(const Vehicle& srcV);
  		void SetLLA(const float * srcLLA);
  		const float* GetLLA() const; //WHY WAS THIS NAMED GetLLA INSTEAD OF getLLA
  		
		virtual void Move(const float* srcLLA) = 0;
		virtual ~Vehicle ();
		
		friend ostream& operator<<(ostream& os, Vehicle& srcV);
  
		protected:
  		float m_lla[3];

		private:
  		virtual void Serialize (std::ostream& os);


};

#endif
