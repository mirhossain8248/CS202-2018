/*
Mir Hossain
NodeList Implementation File
*/

#include <iostream>
#include "NodeList.h"


std::ostream& operator<<(std::ostream& os, const NodeList& nodeList) //i
{
using std::endl;
	
	Node * current = nodeList.m_head;

    	while(current)
    	{
      		os << current->getData() << endl;
      		current = current->getNext();
    	}
    	return os;
}


/*
Default constructor:
new node object 
*/

NodeList::NodeList()//(1) Done
{
	m_head = new Node;
}

/*
Parameterized constructor:
create new list object which holds size_t count elements, 
*/
NodeList::NodeList(size_t count, const DataType& value) //(2) Done
{
 	if(count <= 0) //Makes sure count isn't 0
  	{
    		m_head = NULL;
  	}
  	
  	else
  	{
    		m_head = new Node(value); //Sets a new value for head
		Node * current = m_head; //Create Object
    			
			while (--count > 0) //Before 0
    			{
      				current->m_next = new Node(value);
      				current = current->m_next;
    			}
    	//deallocate current
    	current = NULL;
    	delete current;
  	}
	
}		

/*
Copy constructor:
Create a new list object which will be a separate copy of the data of the other NodeList object
*/
NodeList::NodeList(const NodeList& other) //(3) Done
{
	if(!other.m_head) //Safety Check for head value
  	{
    		m_head = NULL;
  	}

	else
  	{
    		Node * otherCurrent = other.m_head; //Create Object (Shallow Copy)
    		m_head = new Node (otherCurrent -> m_data); //Allocate Copy
    		Node * current = m_head; //Deep Copy
    		otherCurrent = otherCurrent -> m_next; //Goes to next Data Member

    			while (otherCurrent)
    			{
      				current -> m_next = new Node(otherCurrent -> m_data); //Data inside deep 												copy
      				current = current -> m_next;
      				otherCurrent = otherCurrent -> m_next;
    			}
    		current = NULL; //Memory Stuffs
    		otherCurrent = NULL;
    		delete current;
    		delete otherCurrent;
  	}
}

/*
~Nodelist:
Destory every instance of NodeList object 
*/
NodeList::~NodeList() //(4) Done
{

	size_t count = 0;
  	if(m_head)
  	{
    		Node * del = m_head; //Create object for head
    		
			while(m_head)
    			{
      				m_head = m_head -> m_next; 
      				del->m_next = NULL;
      				delete del;
      				del = m_head; //Makes Null
    			}
    	del = NULL; //Delete Memory  
    	delete del;
  	}	

}

/*
operator=
Checks if rhs is the same as the copy, then return the copy
*/
NodeList& NodeList::operator= (const NodeList& rhs)//(5) Done
{
	if(this == &rhs)
    	return *this;	
}

/*
head:
Returns a pointer to the first node(the head) of a list if it exists, else NULL is returned.
*/
Node* NodeList::head()//(6) Done
{
	if (m_head)
		return m_head;
	else 
		return NULL;
}

/*
tail:
Returns the last Node in the list by traversal.
*/
Node* NodeList::tail()//(7 Done)
{
	if(m_head) 
  	{
    		Node * last = m_head;
    			
			while(last -> m_next)
    			{
      				last = last -> m_next; //Traversal
    			}
    	return last;
  	}
  
	else
    		return NULL;
  
}

/*
Find:
Searches a NodeList for the occurrence of a match to the target value.
If a match is found then it returns the current pointer to the Node
Not 100% sure if this works**
*/
Node* NodeList::Find(const DataType & target, Node * & previous, const Node * start) //8 Done maybe
{
	
	size_t i = 0;
  	if(!m_head)
  	{
    		return NULL; //Check Head
  	}
  
		else
  		{
    			Node * current = m_head;
    				
				while (current)
    				{
      					if(current -> m_data == target) //Check if Data = target
        				{
          					
          					return current;
        				}
      			
    				}
  		}
}

/*
InsertAfter:
searches a list for the target value, if the target value is found it
inserts a new node after this value initialized
*/
Node* NodeList::insertAfter(const DataType& target,const DataType& value) //9
{
	if(!m_head)
    		return NULL; //Head Check
  
	else
  	{
    		Node * current = m_head; //Set current object to head of nodelist
    
			while(current)
    			{
      				if (current -> m_data == target) //compares position
      				{
        				Node * temp = new Node(value); //create temp object for new value
        				temp -> m_next = current -> getNext(); // Go to next value in list
        				current -> m_next = temp; //Set temp object as value
        				return current;
      				}
			current = current->m_next;
    			}
  	}
}

/*
InsertBefore:
Find target value(should be first occurance), then
inserts a value declared in driver prior to target
Implementation should be similar to insertAfter
*/
Node* NodeList::insertBefore(const DataType& target,const DataType& value) //9
{
	if(!m_head)
    		return NULL;
  	else
  	{
    		Node * prev = NULL;
    		Node * current = m_head;
    		prev = current;
    
			while(current)
    			{
      				if(current -> m_data == target)
      				{
        				Node * temp = new Node(value);
        				temp -> m_next = prev -> m_next;
        				prev -> m_next = temp;
        				return temp;
      				}
      			prev = current;
      			current = current -> m_next;
    			}
    		return NULL;
  	}
}

/*
Erase:
Searches a list for a value and Erases a node from the list if the data
matches the target value.
*/
Node* NodeList::erase(const DataType& target) 			//(11)
{
	if(!m_head)
    		return NULL;
	
	else if(!m_head->m_next) //Second Case
  	{
    		if(m_head->m_data == target) //Compares with target to be erased
    		{
      			m_head = NULL;
    		}		
  	}
  
  	else
  	{
    		Node * current = m_head; //Takes last case
   		Node * prev = current;
   			
			 while(current)
    			 {
      				if(current->m_data == target) //Compare with Target
      				{
        				Node * erased = current->m_next; //Goes to next node
        				current->m_next = NULL;
        				return erased; //Replace with erased

      				}
      			
    			}
    		return NULL;
  	}
  	return NULL;
	
 
}


/*
operator[]:
returns the data found at a position within the list
I did what made sense for implementation, but I dont this would actually work
*/
DataType& NodeList::operator[] (size_t position)//(12) Not Done
{
	Node * current = m_head;
    	size_t i = 0;
    	
	while(i < position)
    	{
      		current = current->m_next;
      		
    	}
    
	return (current->m_data);
   
}

/*
operator[]:
returns the data found at a position within the list. 
*/
const DataType& NodeList::operator[] (size_t position) const//(12b) //**Not sure what to do for 12a/12b
{
  	Node * current = m_head;
    	size_t i = 0;
    	
	while(i < position)
    	{
      		current = current->m_next;
    
    	}
    
	return (current->m_data);
}

/*
size():
Returns the size of the current list object.
Gives error
*/
size_t NodeList::size() const             //(13)
{
  	int count = 0; //set count for 0
 
	if(m_head)
  	{
    		Node * current = m_head; //Start at head
    
			while(current)
    			{
      				++count; 
      				current = current->m_next; //go to next value in node
    			}
    		
  	}
  	return count;
}


/*
empty:
Just Checks if theres anything in the node
*/
bool NodeList::empty() const									//(14)
{
	if((!m_head) && (!m_head->m_next))
    		return true;
  
}

/*
Clear():
Clears the contents of a list and leaves it empty.
*/
void NodeList::clear()										//(15)
{

	if(m_head)
  	{
    		Node * del = m_head; //start at head
    
			while(m_head)
    			{
      				m_head = m_head->m_next; //next element
      				del->m_next = NULL;
      				delete del;
      				del = m_head;
    			}
  	}	
  
}


