/*Mir Hossain
ArrayList Implementation File
*/

#include "ArrayList.h"

const size_t MAX = 100;

using std::cout;
using std::endl;

/*
operator<<:
Insertion Operator
*/
std::ostream& operator<<(std::ostream& os, const ArrayList& arrayList) //i
{
  	//os << endl;
  	size_t count = arrayList.m_size;
  	size_t i = 0;
  
	while(count--)
  	{
    		os << arrayList.m_array[i];
  	}
  	return os;
}

/*
Default C-tor:
initializes values
*/
ArrayList::ArrayList(): m_maxsize(MAX)	//(1)
{
  	m_size = 0;
  	m_array = NULL;
}

/*
Param C-tor:
Take count and make into an array, then value should populate list
*/
ArrayList::ArrayList(size_t count, const DataType& value)	//(2)
{
  	m_maxsize = MAX; //Sets maxsize to hundred
  	
	if(count > m_maxsize)
  	{
    		//cout << "List Full" << endl;
    		m_array = NULL;
  	}
	else
    	m_size = count;
	m_array = new DataType[m_size];

  	size_t i = 0;
  	
		while(i < m_size)
    		m_array[i++] = value; //populate list
}

/*
Copy c-tor:
Takes in a constant value of one array and allocates memory of the same
size to this objects m_size members, Gives all 0's?
*/
ArrayList::ArrayList(const ArrayList& other) //(3)
{
	int check = ((int)other.m_size);
  	
	if(check < 0)
  	{
    		m_size = 0;
    		m_array = NULL;
  	}
  
	m_size = other.m_size;
  	m_maxsize = other.m_maxsize;
  	m_array = new DataType[other.m_size];
}

/*
destructor:
deallocate memory of an ArrayList object
*/
ArrayList::~ArrayList()			//(4)
{
	delete [] m_array;
  	m_array = NULL;
  
}

/*
operator =:
Assign the contents of the rhs to the contents of the lhs
Change values of copyList
*/
ArrayList& ArrayList::operator= (const ArrayList& rhs)	//(5)
{
	if(this != &rhs)
  	{
    		m_maxsize = rhs.m_maxsize; //Check Size
    		m_array = new DataType[m_size]; // More memory allocation
    		int count = (int)rhs.m_size; 
    		size_t i = 0;
  	 		
	
		while (count--) //Cycle through count
    		{
        		m_array[i] = rhs.m_array[i];
        		++i;
    		}
	}
  	return *this;
  
}

/*
empty():
returns true if the arrayList is empty
did this beforehand so I could use empty in my later functions
*/
bool ArrayList::empty() const //(14)
{
  	if(!this->m_array)
    	return true;
  		return false;
}

/*
front:
Return first occurence of a value in array 
*/
DataType* ArrayList::front() //(6)
{
	size_t i = 0;
  
	while(i < m_size) //Stay in size of array
  	{
    		if(!empty()) //If array is NOT empty
      		return &m_array[i]; //return first value of ArrayList
  	}
    	
	return NULL;
}

/*
back:
Return last value in the list
*/
DataType* ArrayList::back() //(7)
{
	int count = (int)m_size;
  
	while((count--) > 0) 
  	{
    		if(!empty()) //empty check
     	 	return &m_array[count]; //get the last value
  	}
  	
	return NULL;

  
}

/*
Find:
Go through the array list, while still in size, 
traverse the list and compare every value with the given one
then return a match    
*/
DataType* ArrayList::find(const DataType & target, DataType * & previous, const DataType * start) //8
{
	size_t i = 0;
  	
	while(i < m_size) //stay in the size
  	{
    		if(m_array[i] == target) //first element
    		{
      			if(i > 0)
        		previous = &m_array[i-1]; //if the element is after 
      
		else
        		previous = NULL;
      			return &m_array[i];
    		}
    	++i;
  	}
  	return NULL;
  
}

DataType* ArrayList::insertAfter(const DataType& target, const DataType& value) //9
{
	 
}
   

DataType* ArrayList::insertBefore(const DataType& target, const DataType& value) //10
{
   

}

/*Erase():
erases first member in array
*/
DataType* ArrayList::erase(const DataType& target)		 		//(11)
{

	size_t i = 0;
  
	while(i < m_size) 
  	{
    		if(!empty()) 
      		return &m_array[i]; //Gets first
  	}
	
	if (m_array != NULL)
    	{
        	delete [] m_array;
        	m_array = NULL;
    	}
    	

}
/*operator[]:
returns the value of the DataType array at the current position
*/
DataType& ArrayList::operator[] (size_t position)					//(12)
{
	return m_array[position];
  
}


/*
size():
returns the size of the array
*/
size_t ArrayList::size() const									//(13)
{
 	return m_size; 
}

/*
  clear():
    Clears the contents of an m_array member by deleting it. Then sets the
    m_array to NULL.
*/
void ArrayList::clear()											//(15)
{
	delete [] m_array;
  	m_array = NULL;
}




