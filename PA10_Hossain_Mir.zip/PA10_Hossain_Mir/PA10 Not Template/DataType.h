/*
Mir Hossain
DataList Header File
This is copied form Project8
Most of this was made by Professor Christos
*/

#ifndef DATATYPE_H_
#define DATATYPE_H_

#include <iostream>

class DataType{

	friend std::ostream& operator<<(std::ostream& os, const DataType& dataType);
	friend std::istream& operator>>(std::istream& is, DataType& dataType);

  	public:
    		DataType();
    		DataType(int intVal, double doubleVal);
    		DataType(const DataType& srcData); //Test implementation for copy

    		bool operator==(const DataType& other_dataType) const;
    		DataType& operator= (const DataType& other_dataType);
    		DataType& operator* (const int change); //Test implementation to change values

    		int getIntVal() const;
    		void setIntVal(int i);
    		double getDoubleVal() const;
    		void setDoubleVal(double d);

  	private:
    		int m_intVal;
    		double m_doubleVal;
};

#endif //DATATYPE_H_
