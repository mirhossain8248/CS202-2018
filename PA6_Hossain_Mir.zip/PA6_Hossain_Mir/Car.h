//Mir Hossain
//Car Header File

#ifndef CAR_H
#define CAR_H
#include "Vehicle.h"

#include <iostream>
using namespace std;

	class Car: public Vehicle
	{
		public:
  		Car();
  		Car (const float * srcLLA);
  		Car(const Car& srcCar);
  
  		void setThrottle(const int srcThrottle);
  		int getThrottle() const;
  		void Drive(const int srcThrottle);
  
		virtual void Move(const float * srcLLA);
		virtual ~Car ();
  
		Car& operator= (Car& srcCar);


	private:
  		int m_throttle;
  		virtual void Serialize(std::ostream& os);
	};
#endif
