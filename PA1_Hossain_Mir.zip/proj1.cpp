//Mir Hossain
//CS202
//This program will get a list of 10 names from a file then sort them in alphabetical order
//The order should go: Ares, Danielle, Dannae, Eve, Hector, Juliet, June, Oscar, Romeo, Victor
//Number of Names -> 10 Max Chars -> 8 
#include <iostream>
#include <fstream>
using namespace std;

int alpha(char[], char[]);
void swap(char[], char[]);
int main(void){

	int x = 0;
	int y = 0;
	int z = 0;
	char filea[15], fileb[15]; //File A is input and File B is the output
	char name[100][100];

	cout << "Enter the File Name(names): ";
	  cin >> filea;
	cout << "Enter the Output File Name: ";
	  cin >> fileb;

	ifstream infile(filea);
	ofstream outfile(fileb);



    while ( (x < 10) && (infile >> name[x++]));

	cout << "Unsorted Data (Original Input Order and Name)" << endl;
	cout << "=============================================" << endl;

	for(x = 0; x < 10; x++){
	   cout << name[x] << endl;
				}
	for (x = 0; x < 10; x++){
	     for (y = x; y < 10; y++){
		if(alpha(name[x], name[y])){ 
	swap(name[x], name[y]);

	}
		}
			}
	cout << endl;
	cout << "Sorted Data (Original Input Order and Name)" << endl;
	cout << "===========================================" << endl;

	for (x = 0; x < 10; x++){
		cout <<  name[x] << endl;
	outfile << name[x] << endl;	//Writes the names to fileb
		}
return 0;
}

int alpha(char name1[8] , char name2[8]) { //Function will be used to sort and alphabetize the names


	if(name1[0] != name2[0]) {
return (name1[0] > name2[0]); }

	else(name1[0] != name2[0]); { 
return (name1[0] < name2[0]); }	 //else fixed the remaining issues

}
void swap(char name1[8] , char name2[8]) { //Function to make it possible to swap names

	char temp[8]; //temp will be used to keep a spot for the names and for comparison 
	int x;
	  
	for(x = 0; name1[x] != '\0'; ++x){
		temp[x] = name1[x];  }
		temp[x] = '\0';                      
	for(x = 0; name2[x] != '\0'; ++x){
		name1[x] = name2[x]; }
		name1[x] = '\0';
	for(x = 0; temp[x] != '\0'; ++x) {
		name2[x] = temp[x];  }
		name2[x] = '\0';
	//The 3 for loops test each name against eachother then the next function will order the names
	//Making name1, name2, and temp equal to NULL allowed me to end every string at the NULL

}

int length() { //This function will find the length of each name but will also not be used

	char name[100][100];
	char filea[15];
	int x;
	int y;
	int z;

	cout << "Enter File: ";
	  cin >> filea;

	ifstream infile(filea);
	
	while ( (x < 10) && (infile >> name[x++])); 

	for(x = 0; name[x] != '\0'; x++){
		for(y = x; name[y] != '\0'; y++){ 

	cout << name[x] << endl;
	cout << name[y] << endl;
	}
		}  


return 0;
}

