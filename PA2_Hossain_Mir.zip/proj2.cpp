//Mir Hossain
//This program is a broke version of https://www.enterprise.com
//There are 5 cars and the max array space should be 10
//Program doesn't work unless option 1 is chosen first

#include <iostream>
#include<fstream>
using namespace std;
char filea[10]; //Global variables going to be used for the input file

struct cars{ //Like the movie 
	int year;
	char make[10];
	char model[10];
	float price;
	bool ava; //if the car is available or not 
};

void record(cars cars2[]);
void display(cars cars2[]);
int transfer();
void sort(cars cars2[]);
int cost(cars cars2[]);
void user(cars cars2[]);
int main(void) {

	int option = 0;
	cars cars2[10]; //Like the movie -> cars2 will be used for the functions
		
	 do {
	cout << endl; //Extra line break to make it look organized
	cout << "1. Record the File" << endl;
	cout << "2. Display Car Information" << endl;
	cout << "3. Transfer Information into Another File" << endl;
	cout << "4. List the Cars Based on Price(Low-High)" << endl;
	cout << "5. Total Price After Entering Number of Days" << endl;
	cout << "6. Choice of Car(enter index)" << endl;
	cout << "7. Close the Program" << endl;
	
	cout << "Choose an option: ";
	 cin >> option;
	cout << endl;

	    switch (option) {
	
	case 1:
	record(cars2);
	break;

	case 2:
	display(cars2);
	break;
	
	case 3:
	transfer();
	break;

	case 4:
	sort(cars2);
	break;

	case 5:
	cost(cars2);
	break;

	case 6:
	user(cars2);
	break;

	case 7:
	cout << "End Program" << endl;
	break;

	default:
	cout << "Enter a number between 1 and 7" << endl;		
		}

	}
	while(option != 7); 

return 0;
}

void record(cars cars2[10]) { //Open the file then store everything in an array of structs

	int x;
	ifstream temp; //Gonna be used as a temporary file to store stuff in

	cout << "Enter the input file: ";
	 cin >> filea;

	temp.open(filea); //This opens the file for reading

	for(x = 0; x < 5; x++){
		temp >> cars2[x].year >> cars2[x].make >> cars2[x].model >> cars2[x].price >> cars2[x].ava;
	}	//I think this is the array of structs
	cout << "File has been read, please choose another option" << endl;
}
		
void display(cars cars2[]){ //Display all the info about cars

	int x;
	for(x = 0; x < 5; x++){
		cout << cars2[x].year <<  " " << cars2[x].make << " " << cars2[x].model << ", " << "$" << cars2[x].price << " per day, ";
		//prints out everything except the true/false->EZ fix

	if(cars2[x].ava == 1){
		cout << "Available: True" << endl;
		}
	else {
		cout << "Available: False" << endl;
		}
	}
}

int transfer(){ //Not sure why I made this int 
//This just transfers all the info into another file

	int i;
	string buffer = "";
	char fileb[10];

	cout << "Enter the output file name: ";
	 cin >> fileb;


	ifstream infile(filea);

	ofstream outfile(fileb);

	for(i = 0; infile.eof() == false; i++) //This goes till the end of the file 
		buffer += infile.get(); //ReadS letter by letter
		outfile << buffer;

	cout << "Car information has been transferred into the new file" << endl;

return 0;
}		

		
void sort(cars cars2[]){ //Sorts the cars by price
//Order should be Neon, Outback, Fusion, F150, Tacoma

	int x, y;
	//float price2[5];
	cars temp;

	for(x = 1; x < 5; ++x){
		for(y = 0; y < (5-x); ++y)
			if(cars2[y].price > cars2[y+1].price){
			temp = cars2[y];
			cars2[y] = cars2[y+1];
			cars2[y+1] = temp; //sorts all the cars and makes it so they also swap around
		}
	}

	for(x = 0; x < 5; x++){
		cout << cars2[x].year <<  " " << cars2[x].make << " " << cars2[x].model << ", " << "$" << cars2[x].price << " per day, ";
		

	if(cars2[x].ava == 1){
		cout << "Available: True" << endl;
		}
	else {
		cout << "Available: False" << endl; //Same display as from function 2
		}
	}
}	
	
int cost(cars cars2[]){ //Function to see how much it would cost to rent out a car
//Only display cars that are available

	int x;
	int days;
	float total;

	cout << "How many days is the car going to be rented: ";
	 cin >> days;

	for(x = 0; x < 5; x++){
		total = (days * cars2[x].price); //Gets the total price needed to rent a car
		
	if(cars2[x].ava == 1){  //Only displays the cars that are available
		cout << cars2[x].year <<  " " << cars2[x].make << " " << cars2[x].model << ", " << "$" << total << endl;
		
		}
	
	}
return 0;
}
void user(cars cars2[]){ //Asks the user which car they want to rent, tells if available or not

	int x;
	int index; //Car index
	int days;
	float total;

	for(x = 0; x < 5; x++){
		
		cout << x << "." << cars2[x].year <<  " " << cars2[x].make << " " << cars2[x].model << ", " << "$" << cars2[x].price << " per day, ";
		

	if(cars2[x].ava == 1){
		cout << "Available: True" << endl;
		}
	else {
		cout << "Available: False" << endl;
		}
	}

	cout << endl;
	cout << "Choose from the list of cars above: ";
	 cin >> index;
	
		
	if(cars2[index].ava == 1){

	cout << "How many days would you like to rent it: ";
	 	 cin >> days;
	cout << "The " <<  cars2[index].year << " " << cars2[index].make << " " << cars2[index].model << " has been rented for " << days << " days "; 
		total = (days * cars2[index].price); //Gets the total price needed to rent a car
	cout << "for a total of " << "$" << total << endl; //Full display
 		
		(cars2[index].ava -= 1); //Makes the car no longer available?
				}
	else {
		
		cout << "The " <<  cars2[index].year << " " << cars2[index].make  << " " << cars2[index].model << " is no longer available" << endl;
		}

}
	
	





	
	
 		

