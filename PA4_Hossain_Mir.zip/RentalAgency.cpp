//Reads the file and gets the agency/zip

RentalAgency::RentalAgency() //Gets zipcode
{
  	strcpy(m_name, (char *) " ");

  	int *ziptemp = m_zipcode;
  
	for (int i = 0; i < 5; i++)
  	{
    		ziptemp = 0;
    		ziptemp++;
  	}
  
	ziptemp = m_zipcode;
}

const char* RentalAgency::getName() const
{

return m_name;
}

const int* RentalAgency::getZipcode() const
{

return m_zipcode;
}

RentalCar& RentalAgency::operator[](int index)
{
  	RentalCar* cptr = m_inventory;
  
	for (int i = 0; i < index; i++)
  	{
    		cptr++;
  	}

return *cptr;
}

void RentalAgency::setName(char* newName)
{
 	strcpy(m_name, newName);
}

void RentalAgency::setZipcode(int* newZip) //Gets the zip code
{
  	int* zip_ptr = m_zipcode;

  	for (int i = 0; i < 5; i++)
  	{
    		*zip_ptr = *newZip;
    		zip_ptr++;
    		newZip++;
  	}
  	
	zip_ptr = m_zipcode;
}

void RentalAgency::readData(char* fileptr) //Reads the name of the agency and the zipcode
{
  	char name[20];
  	int zipcode[5];
  	int* tempzip = zipcode;
  	char tempMake[20], tempModel[20], tempSensors[50], tempOwner[50];
  	int tempYear;
  	float tempPrice;
  	bool tempAvailable;

  	RentalCar* carptr = m_inventory;
  	CarSensor* sensorptr = carptr -> getSensor();

	

  	ifstream fileIn;
  	fileIn.clear();
  	fileIn.open(fileptr);
  	fileIn >> name;
  	setName(name);
  	fileIn.get();

  	for (int i = 0; i < 5; i++)
  	{
    		*tempzip = fileIn.get() - '0';
    		tempzip++;
  	}
  
	setZipcode(zipcode);

  	for (int i = 0; i < 5; i++)
  	{
    	fileIn >> tempYear >> tempMake >> tempModel >> tempPrice;
    	fileIn.get(); 
	fileIn.get();
    	fileIn.getline(tempSensors, 50, '}');
    	fileIn >> tempAvailable;

    	if (tempAvailable == 0)
    	{
      		fileIn >> tempOwner;
      		carptr -> setOwner(tempOwner);
    	}

    	carptr -> setYear(tempYear);
    	carptr -> setMake(tempMake);
    	carptr -> setModel(tempModel);
	carptr -> setBasePrice(tempPrice);
    	sensorptr -> setType(tempSensors);
    	carptr -> UpdatePrice();
    	carptr -> setAvailable(tempAvailable);
    	carptr++;
    	sensorptr = carptr -> getSensor();
  	}
}

void RentalAgency::printData() //prints everything
{
  	const int *ziptmp = getZipcode();
  	RentalCar* carptr = m_inventory;

 

  	cout << getName() << ' ';

  	for (int i = 0; i < 5; i++)
  	{
    		cout << *ziptmp;
   		ziptmp++;
	}
  	
	cout << endl << "------------------" << endl;

  	for (int i = 0; i < 5; i++)
  	{
    	carptr -> print();
    	carptr++;
  	}
  
	carptr = m_inventory;
}

