/*
Mir Hossain
Implementation file for NodeQueue
*/
#include <iostream>
#include "ArrayQueue.h"



/*
Default Constructor
Create new queue object with no valid data
*/
ArrayQueue::ArrayQueue() //(1) Done
{
	m_size = 0;
	m_front = m_back;
  
}

/*
Parameterized Constructor:
Takes in  count and DataType values, and creates the list
*/
ArrayQueue::ArrayQueue(size_t count, const DataType& value) //(2) Done
{
	size_t i = 0;
	m_size = count; //initilize values
	m_front = i; //initilize front
	
	while(i < m_size)
	{
		m_back = i;
      		m_array[i++] = value; //fill array
      	}
}
/*
Copy Constructor:
Create a copy of array created in previous function    
*/
ArrayQueue::ArrayQueue(const ArrayQueue& other)	//(3) Done
{
	size_t i = m_front;
	m_front = other.m_front;
	m_back = other.m_back;
	m_size = other.m_size; //Make copies
	
	while(i < m_size)
    	{
      		m_array[i] = other.m_array[i];
      		++i; //Fill Array
    	}
}

/*
clear():
Clears the contents of m_array
*/
void ArrayQueue::clear() //Done				
{
	DataType clearedArray;
	
	while(m_size) 
	{
		(m_size--);
		m_array[m_size] = clearedArray;
  
	}
}

/*
destructor:
Not needed, but does same thing as clear
so I called clear and left 
*/
ArrayQueue::~ArrayQueue() //(4) Done
{
	clear();
}

/*
operator =:
Check if lefthand side is the same as righthand side
*/
ArrayQueue& ArrayQueue::operator= (const ArrayQueue& rhs) //(5) done
{
	if(this == &rhs)
    	return *this;
}

/*
front:
Returns head of queue
*/
DataType& ArrayQueue::front() //6 done
{
	return m_array[m_front];
}

/*
front:
Returns a const reference to the head of the queue
*/
const DataType& ArrayQueue::front() const
{
	return m_array[m_front];
}

/*
back:
returns the tail of the queue;
*/
DataType& ArrayQueue::back() //7 done
{
	return m_array[m_back];
}

/*
back:
returns a const reference to the tail of the queue
*/
const DataType& ArrayQueue::back() const
{
 	return m_array[m_back]; 
}

/*
push:
Inserts a new value to the back of the queue, should check if queue is full
*/
void ArrayQueue::push(const DataType& value) //8 done
{
	if(full())
	{
		return;
	}
	
	else
	{
		m_back = (m_back+1) % ARRAY_MAX; //Required wrap around implementation
    		++m_size;
  	}
  	
  	m_array[m_back] = value; //increase size	
}

/*
pop:
Removes front value in queue + check if empty
*/
void ArrayQueue::pop() //9 doone
{
 	if(empty())
 	{
 		return;
 	}
 	
 	else
 	{
 		m_front=(m_front+1)% ARRAY_MAX;
    		--m_size; 
    	}
}
/*
size():
returns the size of the array
*/
size_t ArrayQueue::size() const	//10 done
{
	return m_size;  
}

/*
empty():
returns true if queue is empty 
*/
bool ArrayQueue::empty() const	//(11) done
{
 	if(m_size == 0)
 	{
 		return true;
 	}
 	else
 	{
 		return false;
 	} 
}

/*
full:
Check if max size is = to size of array //12 done
*/
bool ArrayQueue::full() const
{
	if(m_size == ARRAY_MAX)
	{
		return true;
	}
	
	else
	{
		return false;
	}
  
}



/*
operator<<:
Inputs contents for output
*/
std::ostream& operator<<(std::ostream& os, const ArrayQueue& ArrayQueue) //i
{
 	ArrayQueue.serialize(os);
  	return os; 
}

/*
serialize:
Displays the contents of the array based list using the ostream variable
passed in.
*/
void ArrayQueue::serialize(std::ostream& os) const
{
	if(m_size > 0)
  	{
    		size_t i = m_front;
    
    		while (i <= m_back)
    		{
      			os << m_array[i];
      			++i;
    		}
  	}
}
