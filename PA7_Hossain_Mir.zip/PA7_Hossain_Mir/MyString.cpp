//Mir Hossain
//MyString Implementation File

#include "MyString.h"

//(1)Default Constructor
MyString::MyString()
{
	m_buffer = NULL;
  	m_size = 0;
}

//(2)Parameterized Constructor
MyString::MyString(const char* str)
{
  	m_size = strlen(str) + 1; //Set size
  	buffer_allocate(m_size); //allocate memory
  	strcpy(m_buffer, str); //copy string into m_buffer
}

//(3)Copy Constructor
MyString::MyString(const MyString& other_myStr)
{
  	m_size = other_myStr.m_size; //make equal values
  	buffer_allocate(m_size); //allocate memory
  	m_buffer = other_myStr.m_buffer; //shallow copy
}

//(4)Destructor
MyString::~MyString()
{
	if (m_buffer != NULL) //Checks if theres anything in buffer
    	{
      		m_buffer = NULL; //sets buffet to null
      		delete[] m_buffer; //delete memory
    	}
    	m_size = 0;
}

//(5)Size
int MyString::size() const
{
	return m_size; // //returns currently allocated buffer
}

//(6)Length
int MyString::length() const
{
  	return m_size - 1; //Same as above just doesnt count the null
}

//(7)c_str
const char* MyString::c_str() const
{
  	const char* strPt = m_buffer; //Object data

  	return strPt; 
}

//(8)Checks if the right hand side is the same or not(other_Mystr)
bool MyString::operator== (const MyString& other_myStr) const
{
  	if (strcmp(m_buffer, other_myStr.m_buffer) == 0) //Check rhs
  	{
    		return true;
  	}
	else
	{	
  	
		return false;
	}
}

//(9)Inputs contents from m_buffet into other_myStr 
MyString& MyString::operator= (const MyString& other_myStr)
{
  	buffer_allocate(other_myStr.m_size); //Find size
  	m_buffer = other_myStr.m_buffer; //Sets value to rhs
}

//(10)Concatenates from other_myStr to temp
char* MyString::operator+ (const MyString& other_myStr)
{
  	char* temp = m_buffer; //ref to temp
  	m_size = length() + other_myStr.length() + 1; //find length for memory
  	buffer_allocate(m_size); //allocate size to memory
  	m_buffer = strcat(temp, other_myStr.m_buffer); //concat strings

  	return m_buffer;
}

//(11a) Allows access to index of string though reference
char& MyString::operator[] (int index)
{
  	char* bufferPtr = m_buffer; //Not sure if this works but the program compiles

  	for (int i = 0; i < index; i++) //Ask during PASS
  	{
    		bufferPtr++;
  	}

  	return *bufferPtr;
}

//(11b) Same as 11a but with const? Ask about this during pass
//const char & operator[] (int index) const 
//{
	//char* bufferPtr = m_buffer;

  	//for (int i = 0; i < index; i++)
  	//{
    		//bufferPtr++;
  	//}

  	//return *bufferPtr;

//------- or ------------ 
// return m_buffer[index]
//}

//Output
ostream& operator <<(ostream& out, const MyString& myStr)
{
  	out << myStr.m_buffer << endl;

  	return out;
}

//Resets the contents of the strong
void MyString::buffer_deallocate()
{
  	m_buffer = NULL;
  	m_size = 0;
}

//Checks for allocation
void MyString::buffer_allocate(int size)
{
  	if (m_buffer != NULL)
  	{
    		buffer_deallocate();
  	}
  	
	m_size = size;
  	m_buffer = new char[size]; //New used for memory allocation
}
