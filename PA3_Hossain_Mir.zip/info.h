#ifndef info_h
#define info h
//Header file for project 3 will have everything for the class and the agency

void strcpy(char *fin, char *initial);
int strcmp(char *name1, char *name2); //Had to put these in header file b/c string functions being used

class Cars { //Like the movie

	public:
		Cars();
		Cars(int, char *, char *, float, bool);

	 //Initial Methods
		int getYear();
		char *getMake();
		char *getModel();
		float getPrice();
		bool getAva(); 

	//Final Methods
		bool setYear(int finYear); 
		bool setMake(char *finMake);
		bool setModel(char *finModel); 
		bool setPrice(float finPrice);
		bool setAva(bool finAva);
	//Will be used to store in private variables

	void print(); //Will be used as a print function 
	float estCost(float cost, int days);

	
	private:
		char p_make[25];
		char p_model[25];
		int p_year;
		float p_price;
		bool p_ava;

};


struct Agen{ //Agency 

	char name[20];
	int zipcode[5];
	Cars inventory[5];
};

Cars::Cars(){
	
	p_year = 0;
	*p_make = '\0';
	*p_model = '\0';
	p_price = 0.0f;
	p_ava = false;
}

int Cars::getYear(){ //Since vars were private in header program, have to use returns to assign them to something
return p_year;
}

char* Cars::getMake(){
return p_make;
}

char* Cars::getModel(){
return p_model;
}

float Cars::getPrice(){
return p_price;
}

bool Cars::getAva(){
return p_ava;
}

bool Cars::setYear(int finYear){

	p_year = finYear;
return true;
}

bool Cars::setMake(char *finMake){

	strcpy(p_make, finMake);
return true;
}

bool Cars::setModel(char *finModel){

	strcpy(p_model, finModel);
return true;
}

bool Cars::setPrice(float finPrice){

	p_price = finPrice;
return true;
}

bool Cars::setAva(bool finAva){

	p_ava = finAva;
return true;
}




#endif
