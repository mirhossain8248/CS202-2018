//Header file for RentalAgency

#ifndef RentalAgency_h
#define RentalAgency_h

#include <iostream>
#include <iomanip>

using namespace std;

void strcpy(char *dest, const char *src);
int strcmp(char *name1, char *name2);

class RentalAgency
{
  	public:
    	RentalAgency();

    	const char* getName() const;
    	const int* getZipcode() const;
    	RentalCar& operator[](int index);

    	void setName(char* newName);
    	void setZipcode(int* newZip);

    	void readData(char* fileptr);
    	void printData();
    	void printAvail();

  	private:
    	char m_name[20];
    	int m_zipcode[5];
    	RentalCar m_inventory[5];
};

#endif
