/*
Mir Hossain
NodeStack Implementation File
*/
#include <iostream>
#include "NodeStack.h"

/*
Default constructor:
New stack with no elements     
*/
NodeStack::NodeStack()//1 Done
{
	m_top = NULL;
}

/*
Parameterized constructor:
Invokes a list of new nodes has the size as "count" and fills the list
using the ordered pair
*/
NodeStack::NodeStack(size_t count, const DataType& value) //2 Done
{
	m_top = new Node(value); //Dynamically allocate node
    	Node * current = m_top;
    
    	while (--count > 0)
    	{
      		current = new Node(value);
      		current->m_next = m_top;
      		m_top = current; //Fill the list with the ordered pair form DataType
  	}
   	
    	current = NULL; //Deallocate
    	delete current;
}

/*
Copy constructor:
Makes copy of stack object from parameterized constructor
Same exact thing from NodeQueue, just deleted tail
*/
NodeStack::NodeStack(const NodeStack& other) //(3) Done 
{
  	Node * otherCurrent = other.m_top;
    	m_top = new Node(otherCurrent->m_data);
    	Node * current = m_top;
    	otherCurrent = otherCurrent->m_next; //Makes copy; set up otherCurrent

    	while (otherCurrent)
    	{
      		current->m_next = new Node(otherCurrent->m_data); //DMA
      		current = current->m_next; //Keep making new values for current
      		otherCurrent = otherCurrent->m_next; //Copy set
    	}
    
    	current = NULL;
    	otherCurrent = NULL;
    	delete current;
    	delete otherCurrent;
}

/*
Clear:
Clears the contents of a list and makes empty.
*/
void NodeStack::clear()	//12 								
{
	 if(m_top)
  	 {
    		Node * deleteQueue = m_top;
    			while(m_top) //Start from top
    			{
      				m_top = m_top->m_next; //Traverse
      				deleteQueue->m_next = NULL; //Makes values NULL
      				delete deleteQueue; //Delete
      				deleteQueue = m_top;
    			}
    		deleteQueue = NULL;
    		delete deleteQueue;
  	}
 
}

/*
~NodeStack:
Same as clear()
*/
NodeStack::~NodeStack()	//4				
{
  	clear();
}

/*
operator=
Compare right hand/left hand
*/
NodeStack& NodeStack::operator= (const NodeStack& rhs)	//(5)
{
 	if(this == &rhs)
    	return *this; 
}

/*
empty():
Checks if NodeStack is empty
**Moved empty up since I'll be ref. it for
the next functions
*/
bool NodeStack::empty() const									
{
	if(!m_top)
	{
		return true;
	}
	
	else
	
		return false;
}

/*
top():
Returns a reference to the top element stack.
*/

DataType& NodeStack::top() //6a done
{
	empty(); //empty check
	
	return m_top->m_data;
}

/*
Same as above
*/
const DataType& NodeStack::top() const //6b done
{
  	empty(); //empty check
	
	return m_top->m_data;
}

/*
push():
Inputs a new value on top of stack
*/
void NodeStack::push(const DataType& value) //7 done
{
	Node *tempVal = new Node(value); //make a new spot
	tempVal->m_next = m_top; //Makes a new top
	m_top = tempVal;  
	tempVal = NULL;
	delete tempVal;
}

/*
pop():
Removes top value in stack
*/
void NodeStack::pop() //8 done
{
 	empty(); //empty check
	
	Node * tempVal = m_top; //Make buffer to take spot of head 
	m_top = m_top->m_next; //Give new val to m_front
	tempVal = NULL; 
	delete tempVal; //get rid of old head
}

/*
size():
Returns the size of stack list
*/
size_t NodeStack::size() const  //9 done           
{
	size_t queueSize = 0;
	if(m_top)
	{
		Node * current = m_top;
		while(current)
		{
			++queueSize;
			current = current->m_next;
		}
	current = NULL;
	delete current;
	}
	
	return queueSize; 
}



/*
full():
Check if the stack is full or not
Full size is 7    
*/
bool NodeStack::full() const //10 done
{
	size_t maxSize = 7;
	
	if(size() < maxSize)
	{
		return true;
	}
	else
	{
		return false;
	}
}



/*
operator<<:
Outputs contents of a list 
*/
std::ostream& operator<<(std::ostream& os, const NodeStack& srcstack)
{
    srcstack.serialize(os);
    return os;
}

/*
serialize:
Display list   
*/
void NodeStack::serialize(std::ostream& os) const
{
	Node * current = m_top;
    		
    	size_t i = 1;
    	while(current)
    	{
      		os << current->getData();
      		++i;
      		current = current->getNext();
    	}
}
