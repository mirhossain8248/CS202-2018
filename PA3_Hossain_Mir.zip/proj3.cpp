//Mir Hossain
//Proj3
//This is a broke version of kayak.com

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include "info.h"
using namespace std;


void filein(char filea[], Agen *agentptr);
void display(Agen *agentptr);
float rent(Agen *agentptr);
void flex(Agen *agentptr);
void forSale(char filea[], Agen *agentptr);

int main(){

	char filea[10];
	int option = 0;
	float cost = 0.0f;
	Agen num[3];	
	Agen *agentptr = num; //makes max array size to 3 kept getting seg fault without this

	cout << endl << "Welcome to Kayak.com." << endl;
	cout << "--------------------";

	do
	{
		cout << endl;
		cout << "1 - Enter a file for reading" << endl;
		cout << "2 - Display info about all cars" << endl;
		cout << "3 - Find cost to rent a car" << endl;
		cout << "4 - Find the car to flex on your friends(Most Expensive)" << endl;
		cout << "5 - Display only cars for sale and print to another file" << endl;
		cout << "6 - Exit the program\n" << endl;
		
		cout << "Choose from an option above: ";
		cin >> option;

		switch(option){

			case 1:
				filein(filea, agentptr);
				break;
			case 2:
				display(agentptr);
				break;
			case 3:
				cost = rent(agentptr); //Changes value of cost
				cout << "The car will cost: "; 
				cout << "$" << cost << " total" << endl;
				break;
			case 4:
				cout << "The flex car is: ";
				flex(agentptr);
				break;

			case 5:
				forSale(filea,agentptr);
				break;
			
			case 6:
				cout << "Thanks for using hotels.com" << endl;
				break;
				
			
		}
	}
		while(option != 6);

  return 0;
}

void Cars::print(){

	
	cout << getYear() << " ";
	cout << getMake() << " ";
	cout << getModel() << "," << " ";
	cout << "$" << getPrice() << " per day" << "," << " ";
	cout << "Available: " << boolalpha << getAva() << endl; //boolalpha makes it so 0 = false; 1 = true
}

float Cars::estCost(float cost, int days){ //Used for the rent function

	return cost * days;
}


void strcpy(char *fin, char *initial){ //generic string copy

	while(*initial != '\0'){
	
		*fin = *initial;
		initial++;
		fin++;
	}
	*fin = '\0';
}

int strcmp(char *name1, char *name2){ //generic string compare

	while (*name1 and (*name1 == *name2)){
	
		name1++;
		name2++;
	}

	return *name1 - *name2;
}

void filein(char filea[], Agen *agentptr){ //Asks the user for file input


	int year;
	char make[20], model[20];
	float price;
	bool avail;
	
	int *xptr = agentptr -> zipcode; //Deref to zipcode in agency struct 
 	Cars *carsptr = agentptr -> inventory; //Deref to inventory 
	
	cout << "Please enter the input file name: ";
	  cin >> filea;
	//cout << endl;

	ifstream input;
	input.open(filea);

	for (int x = 0; x < 3; x++){
	
		input >> agentptr -> name;
		input.get();

		for (int y = 0; y < 5; y++){
		
			*xptr = input.get() - '0';
			xptr++;
		}

			for (int z = 0; z < 5; z++){
		
				input >> year >> make >> model >> price >> avail;
			
				carsptr -> setYear(year) ;
				carsptr -> setMake(make);
				carsptr -> setModel(model);
				carsptr -> setPrice(price); 
				carsptr -> setAva(avail); //deref everything
				carsptr++;
		}
		input.get();

		agentptr++;
		xptr = agentptr -> zipcode; //Gets agency and zip
		carsptr = agentptr -> inventory; //Gets cars
	}
		cout << "File has been read, choose another option." << endl;

	
}

void display(Agen *agentptr){ //Displays all info about cars

	int *tempzip = agentptr -> zipcode; //Temp location to store zipcodes
	Cars *carptr = agentptr -> inventory; //Place to store cars

	for (int x = 0; x < 3; x++){ 

		cout << endl;
		cout << agentptr -> name << ' ';
		
		for (int y = 0; y < 5; y++){
		
			cout << *tempzip;
			tempzip++;
		}
		cout << endl;
		cout << "---------------------------";
		cout << endl;
	
			for (int z = 0; z < 5; z++){
		
				carptr -> print();
				carptr++;
		}

	agentptr++;
	tempzip = agentptr -> zipcode;
	carptr = agentptr -> inventory;	
	}
}

float rent(Agen *agentptr){ //Asks for user input then returns how much a car would cost in total

	char agency[20]; 
	char Hertz[10] = "Hertz", Alamo[10] = "Alamo", Budget[10] = "Budget";
	int car = 0;
	int days = 0;
	float cost = 0.0f;

	cout << "Enter which agency (Hertz, Alamo, or Budget) you would like to rent from: ";
	  cin >> agency;
	cout << "Enter index of car(starting at 0): ";
	  cin >> car;
	cout << "Enter number of days to rent: ";
	  cin >> days; 

	Cars *carsptr = agentptr -> inventory;

	if (strcmp(agency, Hertz) == 0){ //Check if Hertz was entered
	
		if (car == 0){ //So the first car would be read
		
			cost = carsptr -> getPrice();
		}

			for (int x = 0; x < car; x++){
		
			carsptr++;
			cost = carsptr -> getPrice();
		}
	}
	else if (strcmp(agency, Alamo) == 0){
	
		agentptr++;//Increment to Alamo
		carsptr = agentptr -> inventory;

		if (car == 0){
		
			cost = carsptr -> getPrice();
		}

			for (int y = 0; y < car; y++){
		
			carsptr++;
			cost = carsptr -> getPrice();
		}
	}
	
	else if (strcmp(agency, Budget) == 0)
	{
		agentptr++;//Increment to Alamo
		agentptr++;//Increment to Budget
		carsptr = agentptr -> inventory;

		if (car == 0){
		
			cost = carsptr -> getPrice();
		}

			for (int z = 0; z < car; z++){
		
				carsptr++;
				cost = carsptr -> getPrice();
		}
		
	}

	return carsptr -> estCost(cost, days);
}

void flex(Agen *agentptr){
//Finds most expensive car

	float largest = 0.0f;
	int aPos = 0; //Postion for agencies
	int cPos = 0; //Position for cars

	Cars *carsptr = agentptr -> inventory;

	for (int x = 0; x < 3; x++){

    		for (int y = 0; y < 5; y++){
    
        		if ((carsptr -> getPrice()) > largest){
        
            			largest = carsptr -> getPrice();
            			aPos = x + 1; //Bubble Sort
            			cPos = y + 1;
        	}
        	carsptr++;
   	   }	
    	agentptr++;
    	carsptr = agentptr -> inventory;
	}

	if (aPos >= 1 and aPos <= 3) {
    	agentptr -= 4 - aPos;	//Goes through every agency 
	carsptr = agentptr -> inventory;
        switch (cPos){
        
            case 1:
                carsptr -> print(); //Car 0
                break;
            case 2:
                carsptr++; //Car 1
                carsptr -> print();
                break;
            case 3:
                carsptr++; //Car 2
		carsptr++;
                carsptr -> print();
                break;
            case 4:
                carsptr++; //Car 3
		carsptr++; 
		carsptr++;
                carsptr -> print();
                break;
            case 5:
                carsptr++; //Car 4
		carsptr++;
		carsptr++; 
		carsptr++;
                carsptr -> print();
                break;
        	}
       
	}
}
void forSale(char filea[], Agen *agentptr){ //Display cars that are for sale and put them in a different file

	int aPos = 0;
	int cPos = 0;

	Cars *carsptr = agentptr -> inventory;

	int i;
	string buffer = "";
	char fileb[10];

	cout << "Enter the output file name: ";
	 cin >> fileb;

	ifstream infile(filea);
	ofstream outfile(fileb);

	for(i = 0; infile.eof() == false; i++) //This goes till the end of the file 
		buffer += infile.get(); //ReadS letter by letter
		outfile << buffer;
	cout << endl << "Cars Available" << endl << "---------------" << endl;

	for (int x = 0; x < 3; x++){
	
		for (int y = 0; y < 5; y++){
		
			if ((carsptr -> getAva()) == 1){ //Checks if true
			
				aPos = x + 1;
				cPos = y + 1;

				switch (aPos){ //Goes through the 3 agencies
				
					case 1:
					carsptr = agentptr -> inventory;
						switch (cPos){ //Goes through every car like the last function
						
							carsptr = agentptr -> inventory;
							case 1:
								carsptr -> print();
								break;
							case 2:
								carsptr++;
								carsptr -> print();
								break;
							case 3:
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
							case 4:
								carsptr++; 
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
							case 5:
								
								carsptr++; 
								carsptr++; 
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
						}
						break;
		
					case 2:
						carsptr = agentptr -> inventory;
						switch (cPos){ //Goes through every car like the last function
						
							carsptr = agentptr -> inventory;
							case 1:
								carsptr -> print();
								break;
							case 2:
								carsptr++;
								carsptr -> print();
								break;
							case 3:
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
							case 4:
								carsptr++; 
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
							case 5:
								
								carsptr++; 
								carsptr++; 
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
						}
						break;
					case 3:
						carsptr = agentptr -> inventory;
						switch (cPos){ //Goes through every car like the last function
						
							carsptr = agentptr -> inventory;
							case 1:
								carsptr -> print();
								break;
							case 2:
								carsptr++;
								carsptr -> print();
								break;
							case 3:
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
							case 4:
								carsptr++; 
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
							case 5:
								
								carsptr++; 
								carsptr++; 
								carsptr++; 
								carsptr++;
								carsptr -> print();
								break;
						}
						break;
				}
			}
		carsptr++;
		}
		agentptr++;
		carsptr = agentptr -> inventory;
		
	}		
}


