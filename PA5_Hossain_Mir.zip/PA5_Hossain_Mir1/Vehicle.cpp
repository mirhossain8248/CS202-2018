//Mir Hossain
//Vehicle implentation file

#include "Vehicle.h"

int Vehicle::s_idgen = 8493657; //Make vin an arbritary number -> I think

int Vehicle::getVin() const
{
      return m_vin;
}

float * Vehicle::getLLA()
{
    	return m_lla;
}

int Vehicle::getIdgen()
{
    	//s_idgen = (std::rand()%69696); //Makes a random VIN number - not supposed to be randomized
	s_idgen++;
    	return s_idgen;
}

int Vehicle::setVin(int srcVin)
{
	return getIdgen();
}

Vehicle::Vehicle():m_vin(getIdgen())
{
	//cout << "Vehicle: " << m_vin << ": Default Constructor" << endl; -> Commented all tests couts out
}

Vehicle::Vehicle(int srcVin, float* srcLLA):m_vin(setVin(srcVin))
{
    	setLongLat(srcLLA);
    	//cout << "Vehicle " << m_vin << ": Parametrized Constructor" << endl;
}

Vehicle::Vehicle(const Vehicle& srcVehicle):m_vin(srcVehicle.m_vin) //copy constructor 
{
    	int i = 0;
    	while (i < 3)
    	{
      		m_lla[i] = srcVehicle.m_lla[i];
      		++i;
    	}
    	
	//cout << "Vehicle " << m_vin << ": Copy Constructor" << endl;
}

Vehicle::~Vehicle ()
{
    
    //cout << "Vehicle " << m_vin << ": destructor" << endl;
}

void Vehicle::move(float* srcDest) //The i cant move thing
{
    	cout << "Vehicle " << m_vin << ": CANNOT MOVE - I DON'T KNOW HOW" << endl;

} 
 
bool Vehicle::setLongLat(float* srcDest) //sets the location of a vehicle
{
	int i = 0;
    	if(!srcDest)
    	{
      		while(i < 3)
        	m_lla[i++] = 0;
    	}
    	
	else
    	{
      		int i = 0;
      		while(i < 3)
      	{
        	m_lla[i] = srcDest[i];
        	++i;
      	}

    	}
    	return true;
}

ostream& operator<< (ostream& os, const Vehicle& srcVehicle) //Output should spit out the info on the cars + this causes an error :(
{
    	 cout << "Vehicle: " << srcVehicle.m_vin << " @[";
    	int i = 0;
    	while(i < 2)
      		os << srcVehicle.m_lla[i++] << ", ";
    		os << srcVehicle.m_lla[i] << "]"<< endl;
    	return os;
}

Vehicle& Vehicle::operator= (const Vehicle& srcVehicle) //Moves the LLA as needed
{
    	int i = 0;
    	while(i < 3)
    	{
     	 	m_lla[i] = srcVehicle.m_lla[i];
      		++i;
    	}
    	
	setVin(srcVehicle.m_vin);

    return *this;
}