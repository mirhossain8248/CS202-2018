//This program will do everything to do the car rental (display and rent option)

RentalCar::RentalCar() //Initilize all variables
{
	m_year = 0;
	strcpy(m_make, (char *) " ");
	strcpy(m_model, (char *) " ");
	m_baseprice = 0.0f;
 	m_finalprice = 0.0f;
	m_available = false;
  	strcpy(m_owner, (char *) "\0");
}

int RentalCar::getYear() const
{
	return m_year;
}

const char* RentalCar::getMake() const
{
	return m_make;
}

const char* RentalCar::getModel() const
{
	return m_model;
}

CarSensor* RentalCar::getSensor()
{
	return m_sensors;
}

float RentalCar::getBasePrice() const
{
	return m_baseprice;
}

float RentalCar::getFinalPrice() const
{
	return m_finalprice;
}

bool RentalCar::getAvailable() const
{
	return m_available;
}

const char* RentalCar::getOwner() const //Get functions
{
	return m_owner;
}

void RentalCar::setYear(int newYear) //Set Functions
{
  	m_year = newYear;
}

void RentalCar::setMake(char* newMake)
{
  	strcpy(m_make, newMake);
}

void RentalCar::setModel(char* newModel)
{
  	strcpy(m_model, newModel);
}

void RentalCar::setBasePrice(float newPrice)
{
  	m_baseprice = newPrice;
}

void RentalCar::setAvailable(bool newAvailable)
{
  	m_available = newAvailable;
}

void RentalCar::setOwner(char* newOwner) //This was supposed to be for the new owner
{
  	strcpy(m_owner, newOwner);
}

void RentalCar::print() //Display all the cars
{
	CarSensor* sensorptr = getSensor();

	cout << getYear() << ' ';
	cout << getMake() << ' ';
	cout << getModel() << ' ';
	cout << '$' << setprecision(2) << fixed << getBasePrice() << " per day "; 
	cout << '{' << sensorptr -> getType() << "} ";
	cout << "Available: " << boolalpha << getAvailable();
	if (getAvailable() == 0)
	{
		cout << ' ' << '[' << getOwner() << ']';
	}
	cout << endl;

}

void RentalCar::UpdatePrice()
{
	CarSensor* sensorptr = getSensor();
	float sensorPrice = sensorptr -> getExtraCost();

	m_finalprice = m_baseprice + sensorPrice;
}

void RentalCar::EstimateCost() //User rents the car ->Couldn't get the name to be inputted
{
	int numDays;
	char response[5], name[20];
	char input[5] = "yes";
	cout << "Would you like to rent the flex car? (yes/no): ";
	cin >> response;

	if (strcmp(response, input) == 0)
	{
		setAvailable(0);

		cout << "Enter how many days will the flex car be rented: ";
		cin >> numDays;
		m_finalprice *= numDays;

		cout << "Enter the name to be rented under: ";
		cin >> name;
		//operator+(name); Pretty sure this is how new name would be added, but just made problems
		
		cout << endl << "Estimated cost will be: $" << m_finalprice << endl;
		cout << "Here is the info for the flex car:" << endl;
		print();
	}
}

