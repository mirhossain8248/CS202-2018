//Mir Hossain
//ProjX
//Driver File
//*Some parts were made by Professor Christos


#include "SmartPtr.h"
//#include "SmartPtr.cpp"

using namespace std;


int main(){

	//Test Default
	cout << endl << "(1)Testing SmartPtr Dflt-ctor" << endl;
  	SmartPtr sp1;  // Default-ctor
  	cout << "Default-ctor worked!" << endl;
  	sp1->SetIntVal(1);
  	sp1->SetDoubleVal(0.25);
  	cout << "Dereference Smart Pointer 1: " << *sp1 << endl;


	//Test Parameterized
  	cout << endl << "(2)Testing SmartPtr Copy-ctor" << endl;
  	SmartPtr sp2 = sp1;  // Copy-initalization (Copy-ctor)
  	cout << "Copy Initilization worked" << endl;
  	cout << "Dereference Smart Pointer 1 Post Assignment:" << *sp1 << endl;
  	cout << "Dereference Smart Pointer 2 Post Assignment: " << *sp2 << endl;
  	sp2->SetIntVal(2);
  	sp2->SetDoubleVal(0.5);
  	cout << "Dereference Smart Pointer 1 Post SetIntVal: " << *sp1 << endl;
  	cout << "Dereference Smart Pointer 2 Post SetIntVal: " << *sp2 << endl;
	

	//Test Copy
	cout << endl << "(3)Testing SmartPtr Assignment Operator" << endl;
  	SmartPtr sp3;
  	sp3 = sp1;  // Assignment operator
  	sp3->SetIntVal(3);
  	sp3->SetDoubleVal(0.75);
  	cout << "Dereference Smart Pointer 1: " << *sp1 << endl;
  	cout << "Dereference Smart Pointer 2: " << *sp2 << endl;
  	cout << "Dereference Smart Pointer 3: " << *sp3 << endl;

	cout << endl << "(4)Destructor" << endl;
	

	cout << endl << "(5)Testing SmartPtr Copy Ctor with Null Data " << endl;
  	SmartPtr spNull(NULL); // NULL-data initialization
  	

	cout << endl << "(6)Testing SmartPTR Copy Ctor with Null Data SmartPtr" << endl;
	SmartPtr spNull_cpy(spNull);

	cout << endl << "(7)Testing SmartPtr Assignment with Null Data SmartPtr" << endl;
	SmartPtr spNull_assign;
	spNull_assign = spNull;

	cout << endl << "(8)End-Of-Scope, Destructor called in reverse order of SmartPTr creation";
	cout << endl;
	//cout << endl;
	//cout << (spNull_assign, spNull_cpy, spNull, sp3, sp2, sp1) << endl;
	
	

	
return 0;
}
