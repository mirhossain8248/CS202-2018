/*Mir Hossain
Proj9
Driver File for NodeList, DataList, ArrayList
*/

#include <iostream>

#include "ArrayQueue.h"
#include "NodeQueue.h"
//#include "DataType.cpp"
//#include "NodeQueue.cpp" 
//#include "ArrayQueue.cpp" 

using namespace std;

int main()
{
	
	cout << "-----------------" << endl;
	cout << "Testing DataType" << endl;
	cout << "-----------------" << endl;

  	DataType myData;
  	cout << "(A)Default Constructor: " << myData << endl;

  	DataType otherData(6, 8.1);
  	//cout << endl << "Pctor check" << endl;
  	cout << "(B)Parameterized Constructor: " << otherData << endl;

  	DataType copyData(otherData);
  	//cout << endl << "Copy ctor check" << endl;
  	cout << "(C)Copy Constructor: " << copyData << endl;

  	DataType assignData = otherData;
  	cout << "(D)Operator =: " << assignData << endl; 

  	//cout << endl << "Test DataType getIntVal()" << endl;
  	cout << "(E)getIntVal(): " << copyData.getIntVal() << endl;

  	//Test DataType setIntVal()
  	//cout << endl << "Test setIntVal()" << endl;
  	copyData.setIntVal(6);
  	cout << "(F)setIntVal: " << copyData.getIntVal() << endl;

  	//cout << endl << "Test DataType getDoubleVal()" << endl;
  	cout << "(G)getDoubleVal: " << copyData.getDoubleVal() << endl;

	//cout << endl << "Test DataType SetDoubleVal()" << endl;
  	copyData.setDoubleVal(8.8);
  	cout << "(H)setDoubleVal: " << copyData.getDoubleVal() << endl;

	cout << "----------------" << endl;
	cout << "DataType Class - Done" << endl;
	cout << "----------------" << endl;
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << endl << "-----------------" << endl;
	cout << "Testing Node Class" << endl;
	cout << "-----------------" << endl;

	Node myNode;
  	cout << "(I)Default Node: "<< myNode;

	Node otherNode(copyData);
  	cout << "(J)Other Node: " << otherNode;

	Node copyNode(otherNode);
  	cout << "(K)Copy Node: " << copyNode;
  	
 	cout << "----------------" << endl;
	cout << "Node Class - Done" << endl;
	cout << "----------------" << endl;

/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << endl << "-----------------" << endl;
	cout << "Testing NodeQueue Class" << endl;
	cout << "-----------------" << endl;
	
	//cout << endl << "Test NodeQueue default C-tor" << endl;
	NodeQueue newList;
	cout << "(1)Default Constructor:(Empty) " << newList << endl;
	
	//cout << endl << "Test NodeQueue parameterized C-tor " << endl;
  	NodeQueue otherList(3, copyData);
  	cout << "(2)Parameterized Constructor: " << otherList << endl;
  	
  	//cout << endl << "TestNodeQueue Copy" << endl;
  	NodeQueue copyList(otherList);
  	cout << "(3)Copy Constructor: " << copyList << endl;
  	
  	cout << "(4)Destructor" << endl;
  	
  	//cout << endl << "Test NodeQueue Operator=" << endl;
  	NodeQueue assignList(3, copyData);
  	assignList = otherList;
  	cout << "(5)Operator=: " << assignList << endl;
  	
  	//cout << endl << "Test NodeQueue front()" << endl;
  	DataType front = otherList.front();
  	cout << "(6a)Front: " << front << endl;
  	cout << "(6b)Front Const: " << front << endl;
  	
  	//cout << endl << "Test NodeQueue back()" << endl;
  	DataType back = assignList.back();
  	cout << "(7a)Back: " << back << endl;
  	cout << "(7b)Back Const: " << back << endl;
  	
  	//cout << endl << "Test NodeQueue push()" << endl;
  	DataType tail(12, 16.6);
  	otherList.push(tail);
  	cout << "(8)Push: " << otherList << endl;
  	
  	//cout << endl << "Test NodeQueue pop()" << endl;
  	otherList.pop();
  	cout << "(9)Pop: " << otherList << endl;
  	
  	//cout << endl << "Test NodeQueue size() " << endl;
  	cout << "(10)Size: " << otherList.size() << endl;
  	
  	//cout << endl << "Test NodeQueue Empty() " << endl;
  	//Error check later when list is cleared
  	//otherList.clear(); clear and empty work 
  	if(otherList.empty()) 
  	{
  		cout << "(11)Empty: NodeQueue list is empty" << endl;
  	}
  	else
  	{
  		cout << "(11)Empty: NodeQueue list isn't empty" << endl;
  	}
  	
  	//cout << endl << "Test NodeQueue Full() " << endl;
  	cout << "(12)Assume that maxSize is 5" << endl;
  	if(otherList.full())
  	{
  		cout << "(12)Full: NodeQueue isn't full" << endl;
  	}
  	else
  	{
  		cout << "(12)Full: NodeQueue is full" << endl;
  	}
  	
  	//cout << endl << "Test NodeQueue clear()" << endl;
  	otherList.clear();
  	cout << "(13)Clear: " << otherList << endl;
  	
  	cout << "(14)Serialize" << endl;
  	
  		cout << endl << "-----------------" << endl;
	cout << "NodeQueue Class-Done" << endl;
	cout << "-----------------" << endl;
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << endl << "-----------------" << endl;
	cout << "Testing ArrayQueue Class" << endl;
	cout << "-----------------" << endl;
  	
  	//cout << endl << "Test ArrayQueue default" << endl;
  	ArrayQueue defaultArray;
  	cout << "(1)Default Constructor:(Empty) " << defaultArray << endl;
  	
  	//cout << endl << Test ArrayQueue Pctr" << endl;
  	ArrayQueue otherArray(2, copyData);
  	cout << "(2)Parameterized Constructor: " << otherArray << endl;
  	
  	//cout << endl << "Test ArrayQueue Copy" << endl;
  	ArrayQueue copyArray(otherArray);
  	cout << "(3)Copy Constructor: " << copyArray << endl;
  	
  	cout << "(4)Destructor: " << endl;
  	
	//cout << endl << "Test ArrayQueue Assignment" << endl;
	ArrayQueue assignmentArray = otherArray;
	cout << "(5)Operator =: " << assignmentArray << endl;
	
	//cout << endl << Test ArrayQueue front/constFront << endl;
	DataType head = otherArray.front();
	cout << "(6a)Front: " << head << endl;

	DataType constHead = otherArray.front();
	cout << "(6b)Const Front: " << constHead << endl;
	
	//cout << endl << Test ArrayQueue back/constback << endl;
	DataType newTail = otherArray.back(); //Named newTail b/c previously used tail
	cout << "(7a)Back: " << tail << endl;

	DataType constTail = otherArray.back();
	cout << "(7b)Const Back: " << constTail << endl;
  	
  	//cout << endl << "Test ArrayQueue push << endl; 
  	DataType pushValue(36, 64.8);
  	otherArray.push(pushValue);
  	cout << "(8)Push: " << otherArray << endl;
  	
  	 //cout << endl << "Test ArrayQueue Pop << endl;
  	 otherArray.pop();
  	 cout << "(9)Pop: " << otherArray << endl;
  	 
  	 //cout << endl << "Test ArrayQueue Size << endl;
  	 cout << "(10)Size: " << otherArray.size() << endl;
  	 
  	//cout << endl << Test ArrayQueue Empty << endl;
  	//Test if array is empty
  	//otherArray.clear(); works
  	if(otherArray.empty()) 
  	{
  		cout << "(11)Empty: ArrayQueue list is empty" << endl;
  	}
  	else
  	{
  		cout << "(11)Empty: ArrayQueue list isn't empty" << endl;
  	}
  	
  	//cout << endl << "Test ArrayQueue Full" << endl;
  	//Tested both ways
  	if(otherArray.full()) 
  	{
  		cout << "(12)Full: ArrayQueue list is full" << endl;
  	}
  	else
  	{
  		cout << "(12)Full: ArrayQueue list isn't full" << endl;
  	}
  	
  	//cout << endl << "Test ArrayQueue Clear" << endl'
  	otherArray.clear();
  	cout << "(13)Clear: " << otherArray << endl;
  	
  	cout << "(14)Serialize" << endl;

	cout << endl << "-----------------" << endl;
	cout << "ArrayQueue Class-Done" << endl;
	cout << "-----------------" << endl;
}
