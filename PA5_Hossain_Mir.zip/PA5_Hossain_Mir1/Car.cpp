//Mir Hossain
//Implementation file for car

#include "Car.h"

char* Car::getPlates() 
{
	return m_plates;
}

int Car::getThrottle () const
{
	return m_throttle;
}

bool Car::setPlates (const char * srcPlates)
{
	strcpy(m_plates, srcPlates);
    	return true;
}

int Car::setThrottle (const int srcThrottle)
{
    	m_throttle = srcThrottle;
    	return m_throttle;
}

bool Car::drive(int srcThrottle)
{
    	if(srcThrottle > 0)
      	m_throttle = srcThrottle;
    	return true;
}

Car::Car()
{
    	setThrottle(0);
    	//cout << "Car: " << m_vin << ": Default Constructor" << endl;
}

Car::Car(const char * srcPlates, int srcThrottle, float * srcLLA): //parameterized constructor
  
	m_throttle(setThrottle(srcThrottle))
{
	strcpy(m_plates, srcPlates);
    	setLongLat(srcLLA);
    	//cout << "Car " << m_vin << ": Parametrized Constructor" << endl;
}

  
Car::Car(const Car& srcCar): //copy constructor
    
	m_throttle(setThrottle(srcCar.m_throttle))
{
	int i = 0;
    
		strcpy(m_plates, srcCar.m_plates);
    
    	while (i < 3)
    {
      
	m_lla[i] = srcCar.m_lla[i];
      	++i;
    }

   //cout << "Car " << m_vin << ": Copy Constructor" << endl;
}

  
Car::~Car() //Destructor
{
    //cout << "Car " << m_vin << ": Destructor" << endl;
}

ostream& operator<<(ostream& os, Car& srcCar) //Insertion Operator
{
	int i = 0;

	
	os << "Car VIN: " << srcCar.getVin() << ", ";
    	os << " Plate: " << srcCar.getPlates() << ", "; //something wrong with this implementation
    	os << " Throttle: " << srcCar.getThrottle() << ", ";
    	os << " Location: @[ ";
    	
    		while(i < 2)
      			os << srcCar.m_lla[i++] << ", ";
    			os << srcCar.m_lla[i] << "]"<< endl;
return os;
}

Car& Car::operator=(const Car& srcCar) //Moves info on one car object to another car object
{
	
	int i = 0;    
	strcpy(m_plates, srcCar.m_plates);
    	setThrottle(srcCar.m_throttle);
   
    	while (i < 3)
    	{
      		m_lla[i] = srcCar.m_lla[i];
      		++i;
    	}
    	
	//cout << "Car " << m_vin << ": Assignment" << endl;
return  *this;
}

void Car::move(float * srcLLA) // Move function for car to another LLA
{
	//DNF - Move Function

    	int i = 0;

	cout << "From: ";
    		while(i < 2)
      			cout << m_lla[i++] << ", ";
    			cout << m_lla[i];
    		while(i < 3)
    		{
      			m_lla[i] = srcLLA[i];
      			++i;
    		}
	cout << endl << "To: ";
		int j = 0;
		
		while (j < 2)
			cout << m_lla[j++] << ", ";
    			cout << m_lla[j];
    		while(j < 3)
    		{
      			m_lla[j] = srcLLA[j];
      			++j;
    		}
}