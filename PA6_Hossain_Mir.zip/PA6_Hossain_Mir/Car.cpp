//Mir Hossain
//Car Implementation File

#include "Car.h"

Car::Car()
{
  	m_throttle = 0;
  	cout << "Car: Default ctor" << endl;
}

Car::Car(const float* srcLLA)
{
  	SetLLA(srcLLA);
  	setThrottle(0);
  	cout << "Car: Parametrized ctor" << endl;
}

Car::Car(const Car& srcCar)
{
  	this->setThrottle(srcCar.m_throttle);
  	cout << "Car: Copy ctor" << endl;
}

Car::~Car()
{
  	cout << "Car: Desturction" << endl;
}

void Car::setThrottle(const int srcThrottle)
{
		if(srcThrottle < 0)
  		{
    			cout << "Throttle = 0 kachigga" << endl; //0 check & like the movie cars2
    			m_throttle = 0;
  		}
  	m_throttle = srcThrottle;
}

int Car::getThrottle() const
{
  return m_throttle;
}

void Car::Drive(const int srcThrottle)
{
		if(srcThrottle < 0)
  		{
    			cout << "Throttle = 0 kachigga" << endl; // 0 check & like the movie cars2
    			m_throttle = 0;
  		}
  	m_throttle = srcThrottle;
}

void Car::Serialize(std::ostream& os)
{
	int i = 0;
  	os << "Car @: [";
  
  		while (i < 2)
  		{
    			os << m_lla[i++] << ", ";
  		}
  	++i;
  	os << m_lla[i] << "]";
  	os << "Throttle: " << m_throttle;
}

Car& Car::operator=(Car& srcCar)
{
  		if(this != &srcCar) //parameter check
  		{
    			setThrottle(srcCar.m_throttle);
  		}
  	cout << "Car: Assignment" << endl;
  	return *this;
}

void Car::Move(const float * srcLLA)
{
	int i = 0;
  	cout << "To: [";
  	
  		while (i < 2)
  		{
    			cout << srcLLA[i] << ", ";
    			++i;
  		}
  
	cout << srcLLA[i] << "]" << endl;
  	Drive(75);
  	cout << "Car: Drive to destination with throttle @75 kachow " << endl; //Like the movie cars1/2/3
}



