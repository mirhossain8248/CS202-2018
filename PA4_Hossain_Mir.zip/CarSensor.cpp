//Will be everything to do with sensors

CarSensor::CarSensor()
{
	strcpy(m_type, (char *) "none");
	m_extracost = 0.0f;
}

CarSensor::CarSensor(char* TypeA)
{
  char gps[20] = "gps", camera[20] = "camera", lidar[20] = "lidar",
       radar[20] = "radar";

	strcpy(m_type, TypeA);

  	if (strcmp(m_type, gps) == 0)
  	{
    		gps_cnt++;
  	}
  	else if(strcmp(m_type, camera) == 0)
  	{
    		camera_cnt++;
  	}
  	else if(strcmp(m_type, lidar) == 0)
  	{
    		lidar_cnt++;
  	}
  	else if(strcmp(m_type, radar) == 0)
  	{
    		radar_cnt++;
  	}
}

const char* CarSensor::getType() const //get functions -> for private variables 
{
	return m_type;
}

float CarSensor::getExtraCost() const
{
	return m_extracost;
}

int CarSensor::getNumSensor() const
{
	return m_num_sensors;
}

int CarSensor::getGPS() const
{
	return gps_cnt;
}

int CarSensor::getCamera() const
{
	return camera_cnt;
}

int CarSensor::getLidar() const
{
	return lidar_cnt;
}

int CarSensor::getRadar() const
{
	return radar_cnt;
}

int CarSensor::gps_cnt = 0;
int CarSensor::camera_cnt = 0;
int CarSensor::lidar_cnt = 0;
int CarSensor::radar_cnt = 0;

void CarSensor::setType(char* newType) //Inputs the attachments into the display and counts the total number
{
	char gps[20] = "gps", camera[20] = "camera", lidar[20] = "lidar", radar[20] = "radar", none[20] = "none";
	//What is the difference between a lidar and a radar

	char finalSensors[50] = "\0";

	char *sensorptr = newType;

	m_num_sensors = 0;
	m_extracost = 0.0; 

	while (*sensorptr != '\0')
	{
		if (m_num_sensors == 3)
		break;

	  if (*sensorptr == 'g') //Gets the first letter
	  {
			for (int x = 0; x < 3; x++)
			{
				sensorptr++;
			}
			gps_cnt++; //Counts numbers of GPS's for all the cars
			m_num_sensors++; //Get the total numbers of sensors

			if (m_num_sensors == 2 || m_num_sensors == 3)
			{
				strcat(finalSensors, (char*) " gps"); //Inputs the second/third attachment
			}
			else
			{
				strcat(finalSensors, (char*) "gps"); //Inputs first attachment 
			}
			setExtraCost(gps);
	  	continue;
	  }
	  else if (*sensorptr == 'c')
	  {
			for (int y = 0; y < 7; y++)
			{
	    	sensorptr++;
			}
			camera_cnt++;
			m_num_sensors++;

			if (m_num_sensors == 2 || m_num_sensors == 3)
			{
				strcat(finalSensors, (char*) " camera");  
			}
			else
			{
			strcat(finalSensors, (char*) "camera"); 
			}
			setExtraCost(camera);
	    continue;
	  }
	  else if (*sensorptr == 'l')
	  {
			for (int z = 0; z < 6; z++)
			{
	    	sensorptr++;
			}
			lidar_cnt++;
			m_num_sensors++;

			if (m_num_sensors == 2 || m_num_sensors == 3)
			{
				strcat(finalSensors, (char*) " lidar");
			}
			else
			{
			strcat(finalSensors, (char*) "lidar");
			}

			setExtraCost(lidar);
	    continue;
	  }
	  else if (*sensorptr == 'r')
	  {
			for (int a = 0; a < 6; a++)
			{
	    	sensorptr++;
			}
			radar_cnt++;
			m_num_sensors++;

			if (m_num_sensors == 2 || m_num_sensors == 3)
			{
				strcat(finalSensors, (char*) " radar");
			}
			else
			{
			strcat(finalSensors, (char*) "radar");
			}

			setExtraCost(radar);
	    
	  }
		else
		{
			
			break;
		}
	}
	strcpy(m_type, finalSensors);
}

void CarSensor::setExtraCost(char *sensorType) //Adds the extra cost it doesn't do anything for the program
{
  	char gps[20] = "gps", camera[20] = "camera", lidar[20] = "lidar", radar[20] = "radar";

  	if (strcmp(sensorType, gps) == 0)
  	{
   		 m_extracost += 5.0;
  	}
  	else if(strcmp(sensorType, camera) == 0)
  	{
    		m_extracost += 10.0;
  	}
  	else if(strcmp(sensorType, lidar) == 0)
  	{
   	 	m_extracost += 15.0;
  	}
  	else if(strcmp(sensorType, radar) == 0)
  	{
    		m_extracost += 20.0;
  	}

}


