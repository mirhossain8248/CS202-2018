/*
Mir Hossain
Implementation file for NodeQueue
*/
#include <iostream>
#include "NodeQueue.h"

/*
Default Constructor
Create new node object with no element(s)
*/
NodeQueue::NodeQueue()	//(1)Done
{
	m_front = NULL;
  	m_back = m_front;
}

/*
Parameterized constructor:
Invokes a list of new nodes has the size as "count" and fills the list
using the ordered pair
*/
NodeQueue::NodeQueue(size_t count, const DataType& value) //(2)Done
{
	m_front = new Node(value); //Dynamically allocate node
    	Node * current = m_front;
    
    	while (--count > 0)
    	{
      		current->m_next = new Node(value);
      		current = current->m_next;
      		m_back = current; //Fill the list with the ordered pair form DataType
  	}
   	
    	current = NULL; //Deallocate
    	delete current;
}


/*
Copy constructor:
Makes copy of queue object from parameterized constructor
*/
NodeQueue::NodeQueue(const NodeQueue& other)	//(3)Done
{
	
	Node * otherCurrent = other.m_front;
    	m_front = new Node(otherCurrent->m_data);
    	Node * current = m_front;
    	otherCurrent = otherCurrent->m_next; //Makes copy; set up otherCurrent

    	while (otherCurrent)
    	{
      		current->m_next = new Node(otherCurrent->m_data); //DMA
      		current = current->m_next; //Keep making new values for current
     		m_back = current; //Take care of tail
      		otherCurrent = otherCurrent->m_next; //Copy set
    	}
    
    	current = NULL;
    	otherCurrent = NULL;
    	delete current;
    	delete otherCurrent;
  
}

/*
Clear:
Clears the contents of a list and makes empty.
*/
void NodeQueue::clear()	//(15) Done
{
	 if(m_front)
  	{
    		Node * deleteQueue = m_front;
    			while(m_front)
    			{
      				m_front = m_front->m_next;
      				deleteQueue->m_next = NULL;
      				delete deleteQueue;
      				deleteQueue = m_front;
    			}
    		deleteQueue = NULL;
    		delete deleteQueue;
  	}
 
}

/*
Destructor:
Same as clear()
*/
NodeQueue::~NodeQueue()	//(4)Done
{
	clear();
}

/*
operator=
Same as every rhs
*/
NodeQueue& NodeQueue::operator= (const NodeQueue& rhs)			//(5)
{
	if(this == &rhs)
    	return *this;
  
}

/*
empty():
Checks if NodeQueue is empty
**Moved empty up since I'll be referecning it for
the next functions
*/
bool NodeQueue::empty() const									//(14)
{
	if(!m_front)
	{
		return true;
	}
	
	else
	
		return false;
	 
 
}

/*
front():
Returns a reference to the head of the queue
*/

DataType& NodeQueue::front() //6a done
{
	empty(); //Check for empty NodeQueue 
	
	return m_front->m_data;
}

/*
front() const:
I think this is the same as previous function?
Ask during pass
*/
const DataType& NodeQueue::front() const //6b done
{
	empty(); //Check for empty NodeQueue 
	
	return m_front->m_data;
}

/*
back():
Returns a reference to the tail of the queue
*/
DataType& NodeQueue::back() //7 done
{
	empty(); //Check for empty NodeQueue 
	
	return m_back->m_data;
 
}

/*
back() const:
Also maybe same as previous function?
*/
const DataType& NodeQueue::back() const //7b done
{
	empty(); //Check for empty NodeQueue 
	
	return m_back->m_data;
  
}

/*
push():
Inserts a new ordered pair to the
back of of the queue
*/
void NodeQueue::push(const DataType& value) //8 done
{
	Node *tempVal = new Node(value); //make a new spot
	m_back->m_next = tempVal;
	m_back = tempVal; //create new value for the tail 
	tempVal = NULL;
	delete tempVal;
}

/*
pop():
Remove the first element in the queue
check if empty first
*/
void NodeQueue::pop() //9 done
{
	empty(); //empty check
	
	Node * tempVal = m_front; //Make buffer to take spot of head 
	m_front = m_front->m_next; //Give new val to m_front
	tempVal = NULL; 
	delete tempVal; //get rid of old head
}

/*
size():
Returns the size of the current ArrayQueue.
*/
size_t NodeQueue::size() const   //(13) Done
{
	size_t queueSize = 0;
	if(m_front)
	{
		Node * current = m_front;
		while(current)
		{
			++queueSize;
			current = current->m_next;
		}
	current = NULL;
	delete current;
	}
	
	return queueSize; 
}

/*
full():
will always return false because there aren't any size limitations set on
the Node based queue.
*/
bool NodeQueue::full() const //Not sure which number but done
{
	size_t maxSize = 5; //Assume that list has max 5 size
	
	if(size() < maxSize)
	{
		return true;
	}
  	
  	else
  	{
  		return false;
  	}
}



/*
serialize:
Displays the contents of the node based List using the ostream variable
passed in.
*/
void NodeQueue::serialize(std::ostream& os) const
{
	Node * current = m_front;
    		
    	size_t i = 1;
    	while(current)
    	{
      		os << current->getData();
      		++i;
      		current = current->getNext();
    	}
}

/*
operator<<:
Outputs list
*/
std::ostream& operator<<(std::ostream& os, const NodeQueue& srcQueue)
{
	srcQueue.serialize(os);
    	return os;
}
