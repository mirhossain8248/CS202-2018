//Mir Hossain
//Header file for Car

#ifndef _CAR_H
#define _CAR_H

#include "Vehicle.h"


class Car: public Vehicle
{
  	public:
    	Car();
   	Car(const char * srcPlates, int srcThrottle, float * srcLLA); // parameterized constructor
    	Car(const Car&); // copy constructor
    	~Car(); //Destructor
    	Car& operator= (const Car& srcCar); //assignment operator
    	char* getPlates();
    	int getThrottle() const;
    	bool setPlates(const char* srcPlates);
    	int setThrottle(const int srcThrottle);
    	bool drive(int srcThrottle); //sets throttle speed
    	void move(float* srcLLA); //move for LLA

	friend ostream& operator<<(ostream& os, Car& srcCar); //insertion operator

  private:
    	char m_plates[256];
    	int m_throttle;
};

#endif 