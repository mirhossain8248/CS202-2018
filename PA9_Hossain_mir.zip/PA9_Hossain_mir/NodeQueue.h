/*
Mir Hossain
NodeQueue Header File
Most of this was made by Professor Christos
*/
#ifndef NodeQueue_H_
#define NodeQueue_H_

#include "DataType.h"

//Just copied and pasted Node Class from previous project 
class Node{

  	friend class NodeQueue;  //allows direct accessing of link and data from class NodeQueue

  	friend std::ostream& operator<< (std::ostream& os, const Node& srcNode)
  	{
    		os << srcNode.m_data << std::endl;
    		return os;
  	}

public:
    	Node():
    	m_next( NULL )
	{
	}
	
	Node(const DataType& data, Node* next = NULL) :
	m_next( next ),
	m_data( data )
	{
	}
	
	Node(const Node& other) :
	m_next( other.m_next ),
	m_data( other.m_data )
	{
	}

    	DataType& getData()
    	{  
      	return m_data;
    	}

    DataType& setData(int intVal, double doubleVal)
    {
      	m_data.setIntVal(intVal);
      	m_data.setDoubleVal(doubleVal);
      	return m_data;
    }

    const DataType& getData() const
    {  
      	return m_data;
    }

    Node* getNext() const 
    {
      	return m_next;
    }

private:
    	Node* m_next;
    	DataType m_data;
};

class NodeQueue{
  
  	friend std::ostream& operator<<(std::ostream& os, const NodeQueue& nodeQueue);
public:
    
    	NodeQueue();								    		//(1)
    	NodeQueue(size_t count, const DataType& value);		//(2)
    	NodeQueue(const NodeQueue& other);					//(3)
    	~NodeQueue();							   			//(4)

    	NodeQueue& operator= (const NodeQueue& rhs); //(5)

    	DataType& front(); //(6)
    	const DataType& front() const; //(7)

    	DataType& back(); //8a
    	const DataType& back() const; //8b

    	void push(const DataType& value); //9
    	void pop(); //10

    	size_t size() const; //11
    	bool empty() const; //12
    	bool full() const; //13
    	void clear(); //14
    	void serialize(std::ostream& os) const; 

private:
    	Node *m_front;
    	Node *m_back;
};

#endif //NodeQueue_H_
