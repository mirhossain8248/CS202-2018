/*
Mir Hossain
Implementation file for ArrayStack
*/
#include "ArrayStack.h"

/*
Default Constructor:
New ArrayStack with nothing
*/
ArrayStack::ArrayStack() //1 done
{
	m_top = 0;
}

/*
Parameterized Constructor:
Takes in  count and DataType values, and creates the list
*/
ArrayStack::ArrayStack(size_t count, const DataType& value)//2 done
{
	size_t i = 0;
	m_top = count; //initilize values

	
	while(i < m_top)
	{
      		m_container[i] = value; //fill array
      		i++; //Seperated b/c made 0,0 first element in the stack
      	}
}

/*
Copy Constructor:
Create a copy of array created in previous function   
*/
ArrayStack::ArrayStack(const ArrayStack& other)	//3 done
{
	m_top = other.m_top; //copy top
	size_t i = 0;
	
	while(i < m_top)
	{
		m_container[i] = other.m_container[i];
		i++;
	}
}

/*
destructor:
Not needed, but does same thing as clear
so I called clear and left
*/
ArrayStack::~ArrayStack() //4
{
	clear();  
}

/*
Operator=
Checks if rhs and lhs are the same
*/
ArrayStack& ArrayStack::operator= (const ArrayStack& rhs) //5 Done
{
	if(this == &rhs)
		return *this;
}

/*
top:
Returns head of stack
*/
DataType& ArrayStack::top() //6a Done
{
	if(!empty()) //Checks if array isn't empty
  		return m_container[m_top-1];
  	/*
	Original implementation was m_container[m_top]
	that would give me 0,0
	Should ask about this later
	*/
}

/*
const top:
Returns head of stack
*/
const DataType& ArrayStack::top() const //6b Done
{
	if(!empty()) //Checks if array isn't empty
 		return m_container[m_top-1]; 
}

/*
push:
Inserts a new value to the back of the queue, should check if queue is full
*/
void ArrayStack::push(const DataType& value) //7 Done
{
	if(full())
	{
		return;
	}
	
	else
	{
		m_container[m_top++] = value;
	}	
}

/*
pop:
Removes top element of stack and checks empty
*/
void ArrayStack::pop() //8 Done
{
  	if(empty())
  	{
  		return;
  	}
  	
  	else
  	{
  		(--m_top);
  	}
}
/*
size():
Returns the size of stack
*/
size_t ArrayStack::size() const	//9 done								
{
	return m_top;  
}

/*
empty():
Checks if stack is empty
*/
bool ArrayStack::empty() const	//10 done
{
	if(m_top == 0)
 	{
 		return true;
 	}
 	else
 	{
 		return false;
 	} 
 
}

/*
full:
Check if max stacksize is = to size of array //11 done
*/
bool ArrayStack::full() const
{
  	if(m_top == (MAX_STACKSIZE-1))
	{
		return true;
	}
	
	else
	{
		return false;
	}
}

/*
clear():
Clears the contents of m_top  
*/
void ArrayStack::clear()										
{
	
	while(m_top) 
	{
		(m_top--);
		m_container[m_top];
  
	}  
}

/*
operator<<:
Inputs contents for output
*/
std::ostream& operator<<(std::ostream& os, const ArrayStack& arrayStack)
{
  	arrayStack.serialize(os);
 	return os;
}

/*
serialize:
Displays the contents of the array based list using the ostream variable
passed in.
*/
void ArrayStack::serialize(std::ostream& os) const
{
  	if(m_top > 0)
  	{
    		size_t i = 0;
    			while (i < m_top)
    			{
      				os << m_container[i];
      				++i;
    			}
  	}
}
