//Mir Hossain
//This program is a broke version of PaylessCarRentals.com
//Proj4

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include "CarSensor.h"
#include "CarSensor.cpp"
#include "RentalCar.h"
#include "RentalCar.cpp"
#include "RentalAgency.h"
#include "RentalAgency.cpp"
using namespace std;


void readInput(char* fileptr, RentalAgency& agency);
void printData(RentalAgency& agency);
int sensorData(CarSensor& sensor);
void flex(RentalAgency& agency);
void strcpy(char *dest, const char *src);
int strcmp(char *name1, char *name2);
char* strcat(char* dest, const char* src);

int main()
{
  char filename[20];
  char* fileptr = filename;
  int option = 0;


  RentalAgency agency;
  CarSensor sensor;

  cout << "Enter the input file name: ";
  cin >> fileptr;
  cout << endl;

  do
  {
	cout << endl;
  	cout << "Welcome to Enterprise.com:" << endl;
  	cout << "--------------------------" << endl;
  	cout << "1 - Record data from file" << endl;
  	cout << "2 - Print the cars" << endl;
  	cout << "3 - Print total number of sensors" << endl;
  	cout << "4 - Rent the flex car" << endl;
  	cout << "5 - Exit the program\n" << endl;

  	cout << "Enter an option: ";
  	cin >> option;
	cout << endl;

  	switch(option)
  	{
  		case 1:
        		readInput(filename, agency);
        		cout << "The file has been successfully read.\n" << endl;
  			break;

  		case 2:
			printData(agency);
  			break;

  		case 3:
			cout << "The total number of sensors in the agency's car fleet is: ";
        		cout << sensorData(sensor) << endl << endl;
  			break;

  		case 4:
			cout << "The most flex car is:" << endl << endl;
        		flex(agency);
			break;

  		case 5:
			
			cout << "Thanks for using Hertz.com" << endl;
			break;
  	}
  }
	while(option != 5);

return 0;
}

void readInput(char* fileptr, RentalAgency& agency)
{
	agency.readData(fileptr);
}

void printData(RentalAgency& agency)
{
	agency.printData();
}

int sensorData(CarSensor& sensor)
{
return sensor.getGPS() + sensor.getCamera() +
       sensor.getLidar() + sensor.getRadar();
}

void flex(RentalAgency& agency) //Gets the most expensive car
{
	float largest = 0.0f;
	int carPosition = 0;
	int index;

	for (int i = 0; i < 5; i ++)
	{
		float finalPrice = agency.operator[](i).getFinalPrice();
		bool availability = agency.operator[](i).getAvailable();

    		if ((finalPrice > largest) && (availability))
    		{
      			largest = finalPrice;
      			carPosition = i + 1;
    		}
  	}

	switch (carPosition)
  	{
    		case 1:
      			index = 0;
      			agency.operator[](index).print();
      			break;
    
		case 2:
      			index = 1;
      			agency.operator[](index).print();
      			break;

    		case 3:
     			index = 2;
      			agency.operator[](index).print();
      			break;

    		case 4:
      			index = 3;
      			agency.operator[](index).print();
      			break;

    		case 5:
      			index = 4;
      			agency.operator[](index).print();
      			break;
    			deafult:
      			break;
 	}

  	if (agency.operator[](carPosition - 1).getAvailable() == 1)
  	{
    		agency.operator[](carPosition - 1).EstimateCost();
  	}
  
}

void strcpy(char *dest, const char *src) //Generic String Copy
{
	while(*src != '\0')
	{
		*dest = *src;
		src++;
		dest++;
	}
	*dest = '\0';
}

int strcmp(char *name1, char *name2) //Generic String Compare
{
	while (*name1 && (*name1 == *name2))
	{
		name1++;
		name2++;
	}

return *name1 - *name2;
}

char* strcat(char* dest, const char* src) //Generic String Concatenate
{
  	char* newDest = dest;

  	while(*dest != '\0')
  	{
    		dest++;
  	}
  	
	while (*dest = *src)
  	{
    	dest++;
    	src++;
  	}

return newDest;
}
