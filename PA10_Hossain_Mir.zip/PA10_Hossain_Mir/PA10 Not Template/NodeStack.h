/*
Mir Hossain
NodeStack Header File
Most of this was made by Professor Christos
*/
#ifndef NodeStack_H_
#define NodeStack_H_

#include "DataType.h"

//Just copied and pasted Node Class from previous project 
class Node{

  	friend class NodeStack;  //allows direct accessing of link and data from class NodeQueue

  	friend std::ostream& operator<< (std::ostream& os, const Node& srcNode)
  	{
    		os << srcNode.m_data << std::endl;
    		return os;
  	}

public:
    	Node():
    	m_next( NULL )
	{
	}
	
	Node(const DataType& data, Node* next = NULL) :
	m_next( next ),
	m_data( data )
	{
	}
	
	Node(const Node& other) :
	m_next( other.m_next ),
	m_data( other.m_data )
	{
	}

    	DataType& getData()
    	{  
      	return m_data;
    	}

    DataType& setData(int intVal, double doubleVal)
    {
      	m_data.setIntVal(intVal);
      	m_data.setDoubleVal(doubleVal);
      	return m_data;
    }

    const DataType& getData() const
    {  
      	return m_data;
    }

    Node* getNext() const 
    {
      	return m_next;
    }

private:
    	Node* m_next;
    	DataType m_data;
};

class NodeStack{
  
  	friend std::ostream& operator<<(std::ostream& os, const NodeStack& NodeStack);
public:
    	NodeStack();
    	NodeStack(size_t count, const DataType& value);
    	NodeStack(const NodeStack& other);
    	~NodeStack();

    	NodeStack& operator= (const NodeStack& rhs);

    	DataType& top();
    	const DataType& top() const;

    	void push(const DataType& value);
    	void pop();

    	size_t size() const;
    	bool empty() const;
    	bool full() const;
    	void clear();
    	void serialize(std::ostream& os) const;

private:
    	Node* m_top;
};

#endif //NodeStack_H_
	
