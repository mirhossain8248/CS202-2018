//Header for Cars

#ifndef RentalCar_h
#define RentalCar_h

#include <iostream>
#include <iomanip>

using namespace std;

void strcpy(char *dest, const char *src);
int strcmp(char *name1, char *name2);

class RentalCar
{
  	public:
    	RentalCar();
    	RentalCar(int initYear, char* initMake, char* initModel, float initPrice, bool initAvailable, char* initOwner);
    	RentalCar(RentalCar& obj);

    	int getYear() const;
    	const char* getMake() const;
    	const char* getModel() const;
    	float getBasePrice() const;
    	float getFinalPrice() const;
    	CarSensor* getSensor();
    	bool getAvailable() const;
    	const char* getOwner() const;

    	void setYear(int newYear);
    	void setMake(char* newMake);
    	void setModel(char* newModel);
   	void setBasePrice(float newPrice);
    	void setAvailable(bool newAvailable);
    	void setOwner(char* newOwner);

    	void print();
    	void UpdatePrice();
    	void EstimateCost();
    	

  private:
    	int m_year;
    	char m_make[20];
    	char m_model[20];
    	float m_baseprice;
    	float m_finalprice;
    	CarSensor m_sensors[3];
    	bool m_available;
    	char m_owner[50];
};

#endif
