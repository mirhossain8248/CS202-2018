//Mir Hossain
//Proj7
//The Contents of this file was created by Professor Christos Papachristos (cpapachristos@unr.edu)
#include <iostream>
#include "MyString.h"
//#include "MyString.cpp"

using namespace std;


int strlen (const char* str);
void strcpy(char* dest, const char* src);
int strcmp(const char* str1, const char* str2);
char* strcat(char* dest, const char* src);

int main()
{
  	//(1)
  	MyString ms_default();
	cout << "1 - Default Constructor" << endl;
  	
	//(2)
  	MyString ms_parametrized("MyString parametrized constructor!");
	cout <<"2 - Parameterized Constructor: " << ms_parametrized.c_str() << endl;
  	
	//(3)
  	MyString ms_copy(ms_parametrized);
	cout <<"3 - Copy Constructor: " << ms_copy.c_str() << endl;
  	
	//(4)
  	MyString* ms_Pt = new MyString("MyString to be deleted…");
  	delete ms_Pt;
  	ms_Pt = NULL;
	cout <<"4 - Destructed" << endl;
  
	//(5)Note:Should be 21,(6) Should be 20
  	MyString ms_size_length("Size and length test");
  	cout <<"5 - The size of the string is: " << ms_size_length.size() << endl;
  	cout <<"6 - The length of the string is: " << ms_size_length.length() << endl;
  
	//(7)
  	MyString ms_toCstring("C-String equivalent successfully obtained!");
  	cout <<"7 - Check Obtained: " << ms_toCstring.c_str() << endl;
  
	//(8) Note: Should 9 9 
  	MyString ms_same1("The same"), ms_same2("The same");
  		if (ms_same1==ms_same2)
    			cout <<"8a - Check Equivalence: Same success - ";
			cout <<"Size of 1: " << ms_same1.size();
			cout << " Size of 2: " << ms_same2.size() << endl;
  				
	MyString ms_different("The same (NOT)"); //Should this be printing out?
		if (!(ms_same1==ms_different))
    			cout <<"8b - Check difference: " <<  ms_different;
  
	//(9)
  	MyString ms_assign("Before assignment");
  	ms_assign = MyString("After performing assignment");
  	cout <<"9 - New value: " << ms_assign;
	
	//(10)
  	MyString ms_append1("The first part");
  	MyString ms_append2(" and the second");
  	MyString ms_concat = ms_append1 + ms_append2;
	cout <<"10 - Concatenating " << ms_append1.c_str();
	cout << ms_append2.c_str() << endl;
	//cout << ms_concat.c_str() << endl;	
  
	//(11)
  	MyString ms_access("Access successful (NOT)");
  	ms_access[17] = 0;
	cout <<"11a - Access at location: " << ms_access;
	//^^Maybe this is what this is supposed to do
	cout <<"11b - Not Done Yet " << endl;
  
	//12
  	cout <<"12 - Output: " << ms_access << endl;

  
	return 0;
}

//String Length Function
int strlen (const char* str)
{
  	int len = 0;
  	while (*str != '\0')
  	{
    		str++;
    		len++;
  	}
  	return len;
}

//String Copy
void strcpy(char* dest, const char* src)
{
  	while (*src != '\0')
  	{
    		*dest = *src;
    		dest++;
    		src++;
  	}
  	*dest = '\0';
}

//String Compare
int strcmp(const char* str1, const char* str2)
{
	while (*str1 != '\0' && *str2 != '\0' && *str1 == *str2)
  	{
    		str1++;
    		str2++;
  	}
  	if (!str1)
  	{
    		return -1;
  	}
  	else if(!str2)
  	{
    		return 1;
  	}
  	return *str1 -*str2;
}

//String Concatenate
char* strcat(char* dest, const char* src)
{
  	int size_src;
  	int size = strlen(dest) + strlen(src) + 1;
  	char* newDest = new char[size];
  	newDest = dest;

  	for( int i = 0; i < strlen(dest); ++i)
  	{
    		++newDest;
  	}

	size_src = strlen(src);
  
	for (int i = 0; i < size_src; i++)
  	{
    		*newDest = *src;
    		newDest++;
    		src++;
  	}
  	*newDest = '\0';

  	for (int i = 0; i < size - 1; i++)
  	{
    		newDest--;
  	}

  	return newDest;
}
